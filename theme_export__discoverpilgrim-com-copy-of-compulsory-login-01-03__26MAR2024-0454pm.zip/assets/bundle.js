// saloni-remove-other-products-if-bundle-product-presents

// function to remove product from your cart
function removeProductToCartBundle(variantId, lineItemKey) {
  const removeAtcVariant = {
    id: lineItemKey,
    quantity: 0
  };
  console.log(removeAtcVariant);
  $.ajax({
    type: 'POST',
    url: '/cart/change.js',
    dataType: 'json',
    async: false,
    data: removeAtcVariant,
    success: function(){},
    error: function(){}
  });
}

// on cart update
document.addEventListener('cart:updated', function(event) {
  var cart = event.detail.cart; // Get the updated content of the cart
  if(cart.item_count != 0) {
    let cartItems = cart.items;
    let bundleItemsArr = [];
    
    function filterBundleProducts(item) {
      if(Object.keys(item.properties).length !== 0 && item.properties.hasOwnProperty('Box ID')) {
        return bundleItemsArr.push(String(item.id));
      }
    }
    cartItems.filter(filterBundleProducts);
    // console.log("Bundle prods: " + bundleItemsArr);

    if(bundleItemsArr.length != 0) {
      $.map(cart.items, function(item) {
        if(!(Object.keys(item.properties).length !== 0 && item.properties.hasOwnProperty('Box ID'))) {
          removeProductToCartBundle(item.id, item.key);
        }
      });
    }

    setTimeout(function() {
      document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
        bubbles: true
      }));
    }, 800);

    if(bundleItemsArr.length != 0) {
      setTimeout(function() {
        $("p.cart-subheading").after('<div class="toast" style="background-color: #003366; color: #ffff00; font-size: 15px; font-weight: 600; line-height: 1.5; padding: 10px 15px; margin: -10px 0 0; text-align: center; width: 100%;" role="alert" aria-live="assertive" aria-atomic="true"><div class="d-flex"><div class="toast-body">Gift Box cannot be clubbed with other products</div></div></div>');
        setTimeout(function() {
          $(".toast").remove();
        }, 2500);
      }, 1800);
    }
  }
});

// on page load
$(document).ready(function() {
  $.getJSON('/cart.js', function(cart){
    executeBundleJs(cart);
    console.log(cart.items);
  });

  function executeBundleJs(cart) {
    if(cart.item_count != 0) {
      let cartItems = cart.items;
      let bundleItemsArr = [];
      
      function filterBundleProducts(item) {
        if(Object.keys(item.properties).length !== 0 && item.properties.hasOwnProperty('Box ID')) {
          return bundleItemsArr.push(String(item.id));
        }
      }
      cartItems.filter(filterBundleProducts);
      // console.log("Bundle prods: " + bundleItemsArr);
  
      if(bundleItemsArr.length != 0) {
        $.map(cart.items, function(item) {
          if(!(Object.keys(item.properties).length !== 0 && item.properties.hasOwnProperty('Box ID'))) {
            removeProductToCartBundle(item.id, item.key);
          }
        });
      }

      setTimeout(function() {
        document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
          bubbles: true
        }));
      }, 800);

      if(bundleItemsArr.length != 0) {
        setTimeout(function() {
          $("p.cart-subheading").after('<div class="toast" style="background-color: #003366; color: #ffff00; font-size: 15px; font-weight: 600; line-height: 1.5; padding: 10px 15px; margin: -10px 0 0; text-align: center; width: 100%;" role="alert" aria-live="assertive" aria-atomic="true"><div class="d-flex"><div class="toast-body">Gift Box cannot be clubbed with other products</div></div></div>');
          setTimeout(function() {
            $(".toast").remove();
          }, 2500);
        }, 1800);
      }
    }
  }
});

$(document).on("click", ".line-item__remove-button", function(e) {
  let boxId = $(this).parents(".line-item__info").find(".product-item-meta__property li:last").text().replace("Box ID: ", "");
  $.getJSON('/cart.js', function(cart){
    if(cart.item_count != 0) {
      $.map(cart.items, function(item) {
        if(Object.keys(item.properties).length !== 0 && item.properties.hasOwnProperty('Box ID') && item.properties['Box ID'] == boxId) {
          e.preventDefault();
          removeProductToCartBundle(item.id, item.key);
        }
      });

      setTimeout(function() {
        document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
          bubbles: true
        }));
      }, 800);
    }
  });
});
// saloni-remove-other-products-if-bundle-product-presents