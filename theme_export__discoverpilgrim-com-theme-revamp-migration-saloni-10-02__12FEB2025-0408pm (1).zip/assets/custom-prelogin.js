// saloni-prelogin
// to remove number from session on refresh
$(document).ready(function() {
  sessionStorage.removeItem("verified_num");
  let loggedInOrNot = $('input[name="attributes[loginMethod]"]').val();
  if(loggedInOrNot == "guestUser") {
    updateCartAttr("loginMethod", "guestUser");
  }
});

// update loginMethod in cart attribute
function updateCartAttr(key, val) {
  var formData = new FormData();
  formData.append("attributes["+key+"]", val);
  fetch(window.Shopify.routes.root + 'cart/update.js', {
    method: 'POST',
    body: formData,
    async: true
  })
  .then(response => response.json());
  // .then(data => console.log(data));
}

// focus mobile number field each time truecaller fail
function truecallerFallback() {
  setTimeout(function() {
    $("#mobileForm").find("input#custPhone").focus();
  });
}

function preloginTruecaller() {
  if($(window).width() < 1000 && !(/^((?!chrome|android).)*safari/i.test(navigator.userAgent))) {
    function makeid(length) {
      let result = '';
      const randChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      const randCharsLength = randChars.length;
      let reqCounter = 0;
      while (reqCounter < length) {
        result += randChars.charAt(Math.floor(Math.random() * randCharsLength));
        reqCounter += 1;
      }
      return result;
    }
    
    const UNIQUE_REQUEST_ID = makeid(10);
    const YOUR_APP_KEY = "LHnB186d9a54bd75e4e61a65e36744dc9a4ca";
    const YOUR_APP_NAME = "Pilgrim truecalller";
    window.location = "truecallersdk://truesdk/web_verify?type=btmsheet&requestNonce=" + UNIQUE_REQUEST_ID + "&partnerKey=" + YOUR_APP_KEY + "&partnerName=" + YOUR_APP_NAME + "&lang=en&loginPrefix=checkout&loginSuffix=loginsignup&ctaPrefix=proceedwith&ctaColor=%23faca0c&ctaTextColor=%23000000&btnShape=round&skipOption=manualdetails&ttl=20000";
  
    setTimeout(function() {
      if(document.hasFocus()) {
        // Truecaller app not present on the device and you redirect the user 
        // to your alternate verification page
        truecallerFallback();
      } else {
        // Truecaller app present on the device and the profile overlay opens
        // The user clicks on verify & you'll receive the user's access token to fetch the profile on your 
        // callback URL - post which, you can refresh the session at your frontend and complete the user verification
        let tc_response = setInterval(function() {
          $.ajax({
            type: "GET",
            url: "https://webengagebackup.discoverpilgrim.com/polls/fetch_tc_customer?requestId="+UNIQUE_REQUEST_ID,
            dataType: "json",
            contentType: "application/json",
            success: function(result) {
              if(result['status'] == 200) {
                clearInterval(tc_response);
                updateCartAttr("loginMethod", "cartlogin_truecaller");
                $(".prelogin-tc-wrapper").removeClass("hidden");
                $(".prelogin-tc-loader").attr("open", "open");
                if(result['data']['phoneNumbers'][0]) {
                  let phoneNumber = Number(result['data']['phoneNumbers'][0].toString().slice(-10));
                  try {
                    const customerOrderCount = getCustomerOrderCount(phoneNumber);
                    let customer_type = "new";
                    if(customerOrderCount > 1) {
                      customer_type = "repeat";
                    }
                    
                    const eventData = {
                      "entry_point": $("#prelogin-modal").attr("entry_point"),
                      "mobile_number": phoneNumber,
                      "resend_otp": "False",
                      "method": "truecaller",
                      "customer_type": customer_type
                    };
                    Moengage.track_event("otp_requested", eventData);
  
                    const eventData1 = {
                      "entry_point": $("#prelogin-modal").attr("entry_point"),
                      "mobile_number": phoneNumber,
                      "method": "truecaller",
                      "customer_type": customer_type
                    };
                    Moengage.track_event("otp_verified", eventData1);
                  } catch(err) {
                    // console.log(err.message);
                  }
                  
                  $.ajax({
                    type: "POST",
                    url: "https://webengagebackup.discoverpilgrim.com/polls/generate-multipass-url/",
                    data: JSON.stringify({ mobile_number: phoneNumber }),
                    contentType: "application/json",
                    dataType: "json",
                    success: function(response) {
                      $(".prelogin-tc-wrapper").addClass("hidden");
                      $(".prelogin-tc-loader").removeAttr("open");
                      $(".prelogin-loader").removeClass("hidden");
                      $(".prelogin-content").addClass("hidden");
                      localStorage.setItem("loginRedirectTo", "https://discoverpilgrim.com/checkout");
                      
                      try {
                        const eventData2 = {
                          "entry_point": $("#prelogin-modal").attr("entry_point"),
                          "mobile_number": phoneNumber,
                          "method": "truecaller"
                        };
                        Moengage.track_event("login_success", eventData2);
                      } catch(err) {
                        // console.log(err.message);
                      }
                      finally {
                        window.location.href = response.login_url;
                      }
                    },
                    statusCode: {
                      404: function(request, status, error) {
                        $(".prelogin-tc-wrapper").addClass("hidden");
                        $(".prelogin-tc-loader").removeAttr("open");
                        let userEmail = result['data']['onlineIdentities']['email'];
                        let userName = result['data']['name']['first'] + " " + result['data']['name']['last'];
                        let userPincode = result['data']['addresses'][0]['zipcode'];
                        $("#mobileForm").addClass("hidden");
                        $("#otpForm").addClass("hidden");
                        $("#addressForm").removeClass("hidden");
                        $(".step-mobile").removeClass("active").addClass("completed editMobileBtn");
                        $(".step-address").addClass("active");
                        $("#addressForm #preloginTags").val("cartlogin_truecaller");
                        $("#addressForm").attr("truecaller", "true");
                        $("#addressForm #pincode").focus();
                        if(userPincode) {
                          $("#addressForm #pincode").val(userPincode);
                          $("#addressForm #pincode").trigger("input");
                          $("#addressForm #pincode").parent(".field-wrapper").addClass("hasValue");
                        }
                        sessionStorage.setItem('verified_num', phoneNumber);
                        $(".otp-sent-mobile").text(" +91 " + phoneNumber);
                        $("#addressForm #email").val(userEmail);
                        $("#addressForm #email").parent(".field-wrapper").addClass("hasValue");
                        $("#addressForm #fullName").val(userName);
                        $("#addressForm #fullName").parent(".field-wrapper").addClass("hasValue");
                        $("#mobileForm #custPhone").val(phoneNumber);
                        $("#mobileForm #custPhone").parent(".field-wrapper").addClass("hasValue");
                        $("#addressForm #shippingPhone").val(phoneNumber);
                        $("#addressForm #shippingPhone").parent(".field-wrapper").addClass("hasValue");
                      }
                    },
                    error: function (jqXHR, exception) {
                      if(jqXHR.status != 404) {
                        alert("Something went wrong. Please refresh the page & try again!");
                      }
                    },
                  });
                }
              } else if(result['status'] == 202) {
                clearInterval(tc_response);
                truecallerFallback();
              }
            },
            error: function() {
              alert("Something went wrong. Please refresh the page & try again!");
            }
          });
        }, 500);
  
        setTimeout(function() {
          clearInterval(tc_response);
        }, 20000);
      }
    }, 600);
  } else {
    truecallerFallback();
  }
}

// open login popup on click Checkout button
$(document).on("click", "#prelogin-btn", function() {
  const customerEmail = localStorage.getItem("pg_email");
  const customerId = localStorage.getItem("pg_session");
  if($(this).attr("persistentLogin") == "true" && customerEmail && customerId) {
    updateCartAttr("customerId", customerId);
    window.location.href = "/checkout?checkout[email]="+customerEmail;
  } else {
    $("#prelogin-modal").css("display", "block");
    $("body").css("overflow", "hidden");
    $("#mini-cart").removeAttr("open");
  
    let landingURL = utmSource = utmMedium = utmCampaign = "";
    if(sessionStorage.getItem("pg_landingURL")) {
      landingURL = sessionStorage.getItem("pg_landingURL");
    } else {
      landingURL = "https://discoverpilgrim.com/";
    }
    if(sessionStorage.getItem("pg_utmSource")) {
      utmSource = sessionStorage.getItem("pg_utmSource");
    }
    if(sessionStorage.getItem("pg_utmMedium")) {
      utmMedium = sessionStorage.getItem("pg_utmMedium");
    }
    if(sessionStorage.getItem("pg_utmCampaign")) {
      utmCampaign = sessionStorage.getItem("pg_utmCampaign");
    }
    
    $.getJSON('/cart.js', function(cart) {
      const itemArr = [];
      $.map(cart.items, function(item, index) {
        let itemObj = {};
        itemObj["product_id"] = (item.product_id).toString();
        itemObj["product_title"] = item.product_title;
        itemObj["variant_id"] = (item.variant_id).toString();
        let variantTitle = "Default Title";
        if(item.variant_title) {
          variantTitle = item.variant_title;
        }
        itemObj["variant_title"] = variantTitle;
        itemObj["vendor_name"] = item.vendor;
        itemObj["price"] = parseFloat(item.discounted_price / 100);
        itemObj["quantity"] = parseInt(item.quantity);
        itemObj["index"] = parseInt(index);
  
        itemArr.push(itemObj);
      });

      const eventData = {
        "entry_point": "cartlogin",
        "landing_site": landingURL,
        "utm_source": utmSource,
        "utm_medium": utmMedium,
        "utm_campaign": utmCampaign,
        "items": itemArr
      };
      Moengage.track_event("login_initiated", eventData);
    });
    $("#prelogin-modal").attr("entry_point", "cartlogin");
  
    // check if truecaller login is enabled
    if($(this).attr("tcLogin") == "true") {
      preloginTruecaller();
    } else {
      truecallerFallback();
    }
  }
});

// close popup on click back button
$(document).on("click", "#close-prelogin", function() {
  const pageUrl = window.location.pathname;
  if(pageUrl == "/account/login") {
    window.location.href = "/";
  }
  $("#prelogin-modal").css("display", "none");
  $("body").css("overflow", "unset");
});

// close popup on clicking anywhere for desktop screen
$(document).on("click", function(event) {
  if ($(event.target).closest("#prelogin-modal").is(":visible")) {
    let target = $(event.target);
    if (target.is("#prelogin-modal")) {
      $("#prelogin-modal").css("display", "none");
      $("body").css("overflow", "unset");
    }
  }
});

// {% comment %}
// ------------------------------------------------------------------------------------------------
//   STEP 1:: Mobile
// ------------------------------------------------------------------------------------------------
// {% endcomment %}

// set focus on the field
$(document).on("click", "#prelogin-modal .field-wrapper", function () {
  $(this).closest(".field-wrapper").find("input").focus();
});

// add/remove class to display placeholder accordingly
$(document).on("keyup change", "#prelogin-modal .field-wrapper input", function () {
  var value = $.trim($(this).val());
  if (value) {
    $(this).closest(".field-wrapper").addClass("hasValue");
  } else {
    $(this).closest(".field-wrapper").removeClass("hasValue");
  }
});

// on change phone field
$(document).on("input change", "#mobileForm #custPhone", function(e) {
  $("#phone-error").addClass("hidden");
  $("#sendOtpBtn").removeAttr("disabled");
});

// on keypress phone field, check format, allow numbers only and add space
$(document).on("keypress input", "#mobileForm #custPhone, #addressForm #shippingPhone", function(e) {
  let phoneNum = $(this).val();
  let phoneNum1, newPhoneNum, newPhoneNum1;
  
  if(phoneNum.charAt(0) == "+" && phoneNum.charAt(1) == "9" && phoneNum.charAt(2) == "1") {
    newPhoneNum = phoneNum.substring(3, phoneNum.length);
  } else {
    newPhoneNum = phoneNum;
  }
  if((newPhoneNum+'').match(/^[0-4]/)) {
    newPhoneNum1 = (newPhoneNum+'').replace(/^[0-4]+/g, '');
  } else {
    newPhoneNum1 = newPhoneNum;
  }
  let charCode = (e.which) ? e.which : event.keyCode;
  if (String.fromCharCode(charCode).match(/\D/g)) {
    e.preventDefault();
    phoneNum1 = newPhoneNum1.replace(/\D/g, '');
    $(this).val(phoneNum1);
    return false;
  }
  let newPhone = newPhoneNum1.replace(/ /g, "").replace(/^(\d{5})(\d*)$/, "$1 $2").trim();
  
  $(this).val(newPhone);
  $(this).parent(".field-wrapper").addClass("hasValue");
});

// on paste phone, check format
$(document).bind("paste", "#mobileForm #custPhone", function(e) {
  if (e.target.id === "custPhone" && $(e.target).closest('#mobileForm').length > 0) {
  let phoneNum = e.originalEvent.clipboardData.getData('text');
  let newPhoneNum, newPhoneNum1;
  
  if ((phoneNum+'').match(/[^0-9+\s]/g)) {
    return false;
  }
  if(phoneNum.charAt(0) == "+" && phoneNum.charAt(1) == "9" && phoneNum.charAt(2) == "1") {
    newPhoneNum = phoneNum.substring(3, phoneNum.length).trim();
  } else {
    newPhoneNum = phoneNum;
  }
  if((newPhoneNum+'').match(/^[0-4]/)) {
    newPhoneNum1 = (newPhoneNum+'').replace(/^[0-4]+/g, '').trim();
  } else {
    newPhoneNum1 = newPhoneNum;
  }
  let newPhone = newPhoneNum1.replace(/ /g, "").substring(10).replace(/^(\d{5})(\d*)$/, "$1 $2");
  
  $("#mobileForm #custPhone").val(newPhone);
  $("#mobileForm #custPhone").focus();
  $("#mobileForm #custPhone").parent(".field-wrapper").addClass("hasValue");
  }
});

// on clicking continue button, send OTP
$(document).on("click", "#sendOtpBtn", function() {
  $("#sendOtpBtn").attr("disabled", "disabled");
  const mobileNumber = $('#mobileForm #custPhone').val().replace(" ", "").replace(/^[0-4]+/g, '');

  if(mobileNumber) {
    if(mobileNumber.length != 10) {
      $("#phone-error").removeClass("hidden");
      $("#phone-error").text("Please enter a 10 digit phone number");
    } else {
      $("#phone-error").addClass("hidden");
      let mobile = sessionStorage.getItem('verified_num');
      $(".otp-sent-mobile").text(" +91 " + mobileNumber);

      if(mobile && mobile == mobileNumber) {
        $("#mobileForm").addClass("hidden");
        $("#addressForm").removeClass("hidden");
        $(".step-mobile").removeClass("active").addClass("completed editMobileBtn");
        $(".step-address").addClass("active");
        $("#addressForm #pincode").focus();
        sessionStorage.setItem('verified_num', mobileNumber);
      } else {
        $("#otpForm").find('input.verify_otp').val("");
        sendOtpRequest(mobileNumber);
      }
    }
  } else {
    $("#phone-error").removeClass("hidden");
    $("#phone-error").text("Please enter a valid phone number");
  }
});

// Function to get the customer name based on the mobile number
function getCustomerOrderCount(mobileNumber) {
  const apiUrl = `https://webengagebackup.discoverpilgrim.com/polls/get_customer_name/?mobile_number=${mobileNumber}`;
  let customerOrderCount = 0;
  $.ajax({
    type: "GET",
    url: apiUrl,
    dataType: 'json',
    async: false,
    success: function(response) {
      customerOrderCount = response.customer_order_count;
    }
  });
  return customerOrderCount;
}

// function to send otp
function sendOtpRequest(mobileNumber) {
  if(mobileNumber) {
    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/otp_sender/",
      data: JSON.stringify({ mobile_number: mobileNumber }),
      contentType: "application/json",
      dataType: "json",
      success: function() {
        try {
          const customerOrderCount = getCustomerOrderCount(mobileNumber);
          let customer_type = "new";
          if(customerOrderCount > 1) {
            customer_type = "repeat";
          }
          $("#otpForm").attr("custType", customer_type);
        
          const eventData = {
            "entry_point": $("#prelogin-modal").attr("entry_point"),
            "mobile_number": mobileNumber,
            "resend_otp": "False",
            "method": "manual",
            "customer_type": customer_type
          };
          Moengage.track_event("otp_requested", eventData);
        } catch(err) {
          // console.log(err.message);
        }
        finally {
          $("#mobileForm").addClass("hidden");
          $("#otpForm").removeClass("hidden");
          $("#otpForm").find('input.verify_otp:first').focus();
          let timeLeft = 30;
          let timerId = setInterval(function() {
            if (timeLeft == -1) {
              clearTimeout(timerId);
              $(".resend-otp-text").hide();
              $("#resendOtpBtn").removeClass("disabled");
            } else {
              $("#resend-otp-timer").text("0:" + String(timeLeft).padStart(2, '0'));
              timeLeft--;
            }
          }, 1000);
        }
      },
      statusCode: {
        400: function(request, status, error) {
          $("#phone-error").removeClass("hidden");
          $("#phone-error").text(request.responseJSON.error);
          $("#sendOtpBtn").removeAttr("disabled");
        },
        401: function(request, status, error) {
          $("#phone-error").removeClass("hidden");
          $("#phone-error").text(request.responseJSON.error);
          $("#sendOtpBtn").removeAttr("disabled");
        },
        403: function(request, status, error) {
          $("#phone-error").removeClass("hidden");
          $("#phone-error").text("Sending OTP not allowed for your device/location.");
        },
        429: function(request, status, error) {
          $("#phone-error").removeClass("hidden");
          $("#phone-error").text("OTP request limit exceeded for today.");
        }
      },
      error: function (jqXHR, exception) {
        if(jqXHR.status != 400 && jqXHR.status != 401 && jqXHR.status != 403 && jqXHR.status != 429) {
          $("#phone-error").removeClass("hidden");
          $("#phone-error").text("Error sending OTP. Please try again.");
          $("#sendOtpBtn").removeAttr("disabled");
        }
      }
    });
  }
}

// {% comment %}
// ------------------------------------------------------------------------------------------------
//   STEP 2:: OTP
// ------------------------------------------------------------------------------------------------
// {% endcomment %}

// on keypress type tel fields, allow numbers only
$(document).on("keypress input", '#prelogin-modal .verify_otp, #prelogin-modal #pincode', function(e) {
  let inputVal = $(this).val();
  let charCode = (e.which) ? e.which : event.keyCode;
  if (String.fromCharCode(charCode).match(/\D/g)) {
    e.preventDefault();
    inputVal = inputVal.replace(/\D/g, '');
    $(this).val(inputVal);
    return false;
  }
});

// on input otp, hide error
$(document).on("input change", "#otpForm .verify_otp", function() {
  $("#otp-error").addClass("hidden");
  $("#verifyOtpBtn").removeAttr("disabled");
});

// on input otp, hide error and shift focus to next input field
$(document).on("input", "#otpForm .verify_otp", function() {
  let otpCode = Array.from($('#otpForm .verify_otp')).map(input => $(input).val()).join('').trim();
  let otpArray = otpCode.split('');
  $('#otpForm .verify_otp').val("");
  $("#otpForm .verify_otp").each(function (index, element) {
    $(this).val(otpArray[index]);
    if ($(this).val().length == 1) {
      $(this).parent().next().find('input.verify_otp').focus();
    }
  });

  if(otpCode.length == 4) {
    // Call your OTP verification function here
    $("#verifyOtpBtn").trigger("click");
  }
});

// on keyup, shift focus to next input field
$(document).on("keyup", "#otpForm .verify_otp", function() {
  if ($(this).val().length == 1) {
    $(this).parent().next().find('input.verify_otp').focus();
  }
});

// on keypress, check length of the input
$(document).on("keypress", "#otpForm .verify_otp", function() {
  if ($(this).val().length == 1) {
    return false;
  }
});

// on keydown, control backspace functionality
$(document).on("keydown", "#otpForm .verify_otp", function(e) {
  if (e.which == 8 && $(this).val().length == 0) {
    $(this).parent().prev().find('.verify_otp').focus();
  }
});

// on clicking edit phone button
$(document).on("click", "#editMobileBtn, li.step-mobile.editMobileBtn", function() {
  $("#otpForm").addClass("hidden");
  $("#addressForm").addClass("hidden");
  $(".step-mobile").removeClass("completed editMobileBtn").addClass("active");
  $(".step-address").removeClass("active");
  $("#mobileForm").removeClass("hidden");
  $("#mobileForm").find("input#custPhone").focus();
  $("#sendOtpBtn").removeAttr("disabled");
});

// on clicking resend OTP button
$(document).on("click", "#resendOtpBtn", function() {
  $("#otp-error").addClass("hidden");
  if (!$(this).hasClass('disabled')) {
    $("#continueAsGuestBtn").removeClass("hidden");
    const mobileNumber = $('#mobileForm #custPhone').val().replace(" ", "");
    $(".resend-otp-text").show();
    $("#resendOtpBtn").addClass("disabled");

    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/otp_sender/",
      data: JSON.stringify({ mobile_number: mobileNumber }),
      contentType: "application/json",
      dataType: "json",
      success: function() {
        try {
          const customerType = $("#otpForm").attr("custType");
          const eventData = {
            "entry_point": $("#prelogin-modal").attr("entry_point"),
            "mobile_number": mobileNumber,
            "resend_otp": "True",
            "method": "manual",
            "customer_type": customerType
          };
          Moengage.track_event("otp_requested", eventData);
        } catch(err) {
          // console.log(err.message);
        }
        finally {
          $("#otpForm").find('input.verify_otp').val("");
          $("#otpForm").find('input.verify_otp:first').focus();
          let timeLeft = 30;
          let timerId = setInterval(function() {
            if (timeLeft == -1) {
              clearTimeout(timerId);
              $(".resend-otp-text").hide();
              $("#resendOtpBtn").removeClass("disabled");
            } else {
              $("#resend-otp-timer").text("0:" + String(timeLeft).padStart(2, '0'));
              timeLeft--;
            }
          }, 1000);
        }
      },
      statusCode: {
        400: function(request, status, error) {
          $("#otp-error").removeClass("hidden");
          $("#otp-error").text(request.responseJSON.error);
        },
        401: function(request, status, error) {
          $("#otp-error").removeClass("hidden");
          $("#otp-error").text(request.responseJSON.error);
        },
        403: function(request, status, error) {
          $("#otp-error").removeClass("hidden");
          $("#otp-error").text("Sending OTP not allowed for your device/location.");
        },
        429: function(request, status, error) {
          $("#otp-error").removeClass("hidden");
          $("#otp-error").text("OTP request limit exceeded for today.");
        }
      },
      error: function() {
        if(jqXHR.status != 400 && jqXHR.status != 401 && jqXHR.status != 429) {
          $("#otp-error").removeClass("hidden");
          $("#otp-error").text("Error sending OTP. Please try again.");
        }
      }
    });
  }
  return false;
});

// continue as guest checkout
$(document).on("click", "#continueAsGuestBtn", function() {
  updateCartAttr("loginMethod", "cartlogin_guest");
  let login_url = "https://discoverpilgrim.com/checkout";
  window.location.href = login_url;
});

// on clicking continue button, check format and verify OTP
$(document).on("click", "#verifyOtpBtn", function() {
  $("#verifyOtpBtn").attr("disabled", "disabled");
  $("#otp-error").addClass("hidden");
  const otp = Array.from($('.verify_otp')).map(input => $(input).val()).join('');
  const mobileNumber = $('#mobileForm #custPhone').val().replace(" ", "");
  
  if(otp.length == 4) {
    updateCartAttr("loginMethod", "cartlogin_manual");
    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/verify_otp/",
      data: JSON.stringify({ mobile_number: mobileNumber, otp: otp }),
      contentType: "application/json",
      dataType: "json",
      success: function(response) {
        try {
          const customerType = $("#otpForm").attr("custType");
          const eventData = {
            "entry_point": $("#prelogin-modal").attr("entry_point"),
            "mobile_number": mobileNumber,
            "method": "manual",
            "customer_type": customerType
          };
          Moengage.track_event("otp_verified", eventData);
        } catch(err) {
          // console.log(err.message);
        }
        finally {
          $("#otp-error").addClass("hidden");
          if (response.message.includes("Please signup")) {
            $("#otpForm").addClass("hidden");
            $("#addressForm").removeClass("hidden");
            $(".step-mobile").removeClass("active").addClass("completed editMobileBtn");
            $(".step-address").addClass("active");
            $("#addressForm #preloginTags").val("cartlogin_manual");
            $("#addressForm #pincode").focus();
            sessionStorage.setItem('verified_num', mobileNumber);
          } else {
            $(".prelogin-loader").removeClass("hidden");
            $(".prelogin-content").addClass("hidden");
            localStorage.setItem("loginRedirectTo", "https://discoverpilgrim.com/checkout");
            try {
              const eventData = {
                "entry_point": $("#prelogin-modal").attr("entry_point"),
                "mobile_number": mobileNumber,
                "method": "manual"
              };
              Moengage.track_event("login_success", eventData);
            } catch(err) {
              // console.log(err.message);
            }
            finally {
              window.location.href = response.login_url;
            }
          }
        }
      },
      error: function() {
        $("#otp-error").removeClass("hidden");
        $("#otp-error").text("Invalid OTP. Please try again.");
      }
    });
  } else {
    $("#otp-error").removeClass("hidden");
    $("#otp-error").text("Please enter a valid OTP.");
  }
});

// {% comment %}
// ------------------------------------------------------------------------------------------------
//   STEP 3:: Address
// ------------------------------------------------------------------------------------------------
// {% endcomment %}

// on change address form fields, hide the respective field error
$(document).on("input change", "#fullAddressForm input", function() {
  $(this).parents(".field-wrapper").next("p.input-error").addClass("hidden");
});

// on input pincode, fetch state and city and show address form
$(document).on("input change", "#addressForm #pincode", function() {
  $("#pincode-error").addClass("hidden");
  $("#fullAddressForm").addClass("hidden");
  $("#fullAddressForm").find("input#city, input#state").val("");
  const pincode = $(this).val();
  
  if(pincode.length == 6) {
    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/check_serviceability_direct",
      data: JSON.stringify({ pincode: pincode }),
      contentType: "application/json",
      async: false,
      dataType: "json",
      success: function(data) {
        if(data.serviceable) {
          $.ajax({
            type: "POST",
            url: "https://webengagebackup.discoverpilgrim.com/polls/pincode-details/",
            data: JSON.stringify({ pincode: pincode }),
            contentType: "application/json",
            dataType: "json",
            success: function(response) {
              $("#pincode-error").addClass("hidden");
              $("#addressForm #city").val(response.city);
              $("#addressForm #city").parent(".field-wrapper").addClass("hasValue");
              $("#addressForm #city").parents(".city-state-wrapper").next("p.input-error").addClass("hidden");
              $("#addressForm #state").val(response.state);
              $("#addressForm #state").parent(".field-wrapper").addClass("hasValue");
              $("#addressForm #fullAddressForm").removeClass("hidden");
              $("#addressForm #state").attr("disabled", "disabled");
              $("#addressForm #shippingPhone").val($("#mobileForm #custPhone").val());
              $("#addressForm #shippingPhone").parent(".field-wrapper").addClass("hasValue");
            },
            error: function() {
              $("#pincode-error").removeClass("hidden");
              $("#pincode-error").text("This pincode is not serviceable.");
            }
          });
        } else {
          $("#pincode-error").removeClass("hidden");
          $("#pincode-error").text("This pincode is not serviceable.");
        }
      },
      error: function() {
        $("#pincode-error").removeClass("hidden");
        $("#pincode-error").text("This pincode is not serviceable.");
      }
    });
  } else {
    $("#pincode-error").removeClass("hidden");
    $("#pincode-error").text("Please enter a valid pincode.");
  }
});

// on paste shipping phone, check format
$(document).bind("paste", "#addressForm #shippingPhone", function(e) {
  if (e.target.id === "shippingPhone" && $(e.target).closest('#addressForm').length > 0) {
  let phoneNum = e.originalEvent.clipboardData.getData('text');
  let newPhoneNum, newPhoneNum1;
  
  if ((phoneNum+'').match(/[^0-9+\s]/g)) {
    return false;
  }
  if(phoneNum.charAt(0) == "+" && phoneNum.charAt(1) == "9" && phoneNum.charAt(2) == "1") {
    newPhoneNum = phoneNum.substring(3, phoneNum.length).trim();
  } else {
    newPhoneNum = phoneNum;
  }
  if((newPhoneNum+'').match(/^[0-4]/)) {
    newPhoneNum1 = (newPhoneNum+'').replace(/^[0-4]+/g, '').trim();
  } else {
    newPhoneNum1 = newPhoneNum;
  }
  let newPhone = newPhoneNum1.replace(/ /g, "").substring(10).replace(/^(\d{5})(\d*)$/, "$1 $2");
  
  $("#addressForm #shippingPhone").val(newPhone);
  $("#addressForm #shippingPhone").focus();
  $("#addressForm #shippingPhone").parent(".field-wrapper").addClass("hasValue");
  }
});

// function to check all address form validations
function checkValidation() {
  let error = false;
  const emailRegex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  if(!$("#addressForm #fullName").val()) {
    error = true;
    $("#fullname-error").removeClass("hidden");
    $("#fullname-error").text("Please enter a valid name.");
  } else {
    $("#fullname-error").addClass("hidden");
  }
  if(!$("#addressForm #email").val()) {
    error = true;
    $("#email-error").removeClass("hidden");
    $("#email-error").text("Please enter a valid email.");
  } else if (!emailRegex.test($("#addressForm #email").val())) {
    error = true;
    $("#email-error").removeClass("hidden");
    $("#email-error").text("Email is not valid.");
  } else {
    $("#email-error").addClass("hidden");
  }
  if(!$("#addressForm #address1").val()) {
    error = true;
    $("#address1-error").removeClass("hidden");
    $("#address1-error").text("Please enter a valid address.");
  } else if($("#addressForm #address1").val().length < 12) {
    error = true;
    $("#address1-error").removeClass("hidden");
    $("#address1-error").text("Please enter a minimum 12 characters address.");
  } else {
    $("#address1-error").addClass("hidden");
  }
  if(!$("#addressForm #city").val()) {
    error = true;
    $("#city-error").removeClass("hidden");
    $("#city-error").text("Please enter a valid city.");
  } else {
    $("#city-error").addClass("hidden");
  }
  if(!$("#addressForm #shippingPhone").val()) {
    error = true;
    $("#shipping-phone-error").removeClass("hidden");
    $("#shipping-phone-error").text("Please enter a valid phone number.");
  } else if ($("#addressForm #shippingPhone").val().replace(" ", "").length != 10) {
    error = true;
    $("#shipping-phone-error").removeClass("hidden");
    $("#shipping-phone-error").text("Please enter a 10 digit phone number");
  } else {
    $("#shipping-phone-error").addClass("hidden");
  }
  return error;
}

// function to generate password
function generatePwd(length) {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let password = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }
  return password;
}

// on clicking continue button, register user
$(document).on("click", "#addAddressBtn", function() {
  let pincode = $("#addressForm #pincode").val();
  if(pincode && pincode.length == 6) {
    let validationErr = checkValidation();
    if(!validationErr || validationErr == "false") {
      let fullName = $("#addressForm #fullName").val().trim();
      let fname, lname;
      if(fullName.indexOf(" ") !== -1) {
        let splitName = fullName.split(" ");
        lname = splitName.pop();
        fname = splitName.join(" ");
        if(lname == "") {
          lname = ",";
        }
      } else {
        lname = ",";
        fname = fullName;
      }
      let password = generatePwd(8);
      let mobileNumber = $("#mobileForm #custPhone").val().replace(" ", "");
      let email = $("#addressForm #email").val();
      let address1 = $("#addressForm #address1").val();
      let city = $("#addressForm #city").val();
      let state = $("#addressForm #state").val();
      let pincode = $("#addressForm #pincode").val();
      let shippingPhone = $("#addressForm #shippingPhone").val().replace(" ", "");
      
      const data = {
        first_name: fname,
        last_name: lname,
        mobile_number: mobileNumber,
        email: email,
        password: password,
        autopopup: "yes",
        address1: address1,
        city: city,
        state: state,
        pincode: pincode,
        shipping_mobile_number: shippingPhone,
        tags: $("#addressForm #preloginTags").val()
      };
      
      $.ajax({
        type: "POST",
        url: "https://webengagebackup.discoverpilgrim.com/polls/register-address/",
        data: JSON.stringify(data),
        contentType: "application/json",
        success: function(res) {
          $(".step-address").removeClass("active").addClass("completed");
          $(".step-payment").addClass("active");
          $(".prelogin-loader").removeClass("hidden");
          $(".prelogin-content").addClass("hidden");
          localStorage.setItem("loginRedirectTo", "https://discoverpilgrim.com/checkout");
          let loginMethod = "manual";
          let isTruecaller = $("#addressForm").attr("truecaller");
          if(isTruecaller == "true") {
            loginMethod = "truecaller";
          }
          try {
            const eventData = {
              "entry_point": $("#prelogin-modal").attr("entry_point"),
              "mobile_number": mobileNumber,
              "method": loginMethod,
              "first_name": fname,
              "last_name": lname,
              "email": email,
              "address1": address1,
              "city": city,
              "state": state,
              "pincode": pincode,
              "shippingPhone": shippingPhone
            };
            Moengage.track_event("signup_success", eventData);
          } catch(err) {
            // console.log(err.message);
          }
          finally {
            setTimeout(function() {
              window.location.href = res.login_url;
            }, 50);
          }
        },
        error: function(result) {
          let registerErr = false;
          if(result.responseJSON.error) {
            registerErr = true;
            $("#email-error").removeClass("hidden");
            $("#email-error").text(result.responseJSON.error);
          } else if(result.responseJSON.email) {
            registerErr = true;
            $("#email-error").removeClass("hidden");
            $("#email-error").text(result.responseJSON.email);
          }
          if(result.responseJSON.address1) {
            registerErr = true;
            $("#address1-error").removeClass("hidden");
            $("#address1-error").text(result.responseJSON.address1);
          }
          if(result.responseJSON.city) {
            registerErr = true;
            $("#city-error").removeClass("hidden");
            $("#city-error").text(result.responseJSON.city);
          }
          if(result.responseJSON.first_name) {
            registerErr = true;
            $("#fullname-error").removeClass("hidden");
            $("#fullname-error").text(result.responseJSON.first_name);
          }
          if(result.responseJSON.shipping_mobile_number) {
            registerErr = true;
            $("#shipping-phone-error").removeClass("hidden");
            $("#shipping-phone-error").text(result.responseJSON.shipping_mobile_number);
          }
          if(!registerErr) {
            alert("Something went wrong. Please try again later!");
          }
        }
      });
    }
  } else {
    $("#pincode-error").removeClass("hidden");
    $("#pincode-error").text("Please enter a valid pincode.");
  }
});
// saloni-prelogin