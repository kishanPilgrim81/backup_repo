// custom.js backup till 01st-August

/**
 * DEVELOPER DOCUMENTATION
 *
 * Include your custom JavaScript here.
 *
 * The theme Focal has been developed to be easily extensible through the usage of a lot of different JavaScript
 * events, as well as the usage of custom elements (https://developers.google.com/web/fundamentals/web-components/customelements)
 * to easily extend the theme and re-use the theme infrastructure for your own code.
 *
 * The technical documentation is summarized here.
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN A VARIANT HAS CHANGED
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever a the user has changed the variant in a selector. The target get you the form
 * that triggered this event.
 *
 * Example:
 *
 * document.addEventListener('variant:changed', function(event) {
 *   let variant = event.detail.variant; // Gives you access to the whole variant details
 *   let form = event.target;
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * MANUALLY CHANGE A VARIANT
 * ------------------------------------------------------------------------------------------------------------
 *
 * You may want to manually change the variant, and let the theme automatically adjust all the selectors. To do
 * that, you can get the DOM element of type "<product-variants>", and call the selectVariant method on it with
 * the variant ID.
 *
 * Example:
 *
 * const productVariantElement = document.querySelector('product-variants');
 * productVariantElement.selectVariant(12345);
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN A NEW VARIANT IS ADDED TO THE CART
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever a variant is added to the cart through a form selector (product page, quick
 * view...). This event DOES NOT include any change done through the cart on an existing variant. For that,
 * please refer to the "cart:updated" event.
 *
 * Example:
 *
 * document.addEventListener('variant:added', function(event) {
 *   var variant = event.detail.variant; // Get the variant that was added
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN THE CART CONTENT HAS CHANGED
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever the cart content has changed (if the quantity of a variant has changed, if a variant
 * has been removed, if the note has changed...). This event will also be emitted when a new variant has been
 * added (so you will receive both "variant:added" and "cart:updated"). Contrary to the variant:added event,
 * this event will give you the complete details of the cart.
 *
 * Example:
 *
 * document.addEventListener('cart:updated', function(event) {
 *   var cart = event.detail.cart; // Get the updated content of the cart
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * REFRESH THE CART/MINI-CART
 * ------------------------------------------------------------------------------------------------------------
 *
 * If you are adding variants to the cart and would like to instruct the theme to re-render the cart, you cart
 * send the cart:refresh event, as shown below:
 *
 * document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
 *   bubbles: true
 * }));
 *
 * ------------------------------------------------------------------------------------------------------------
 * USAGE OF CUSTOM ELEMENTS
 * ------------------------------------------------------------------------------------------------------------
 *
 * Our theme makes extensive use of HTML custom elements. Custom elements are an awesome way to extend HTML
 * by creating new elements that carry their own JavaScript for adding new behavior. The theme uses a large
 * number of custom elements, but the two most useful are drawer and popover. Each of those components add
 * a "open" attribute that you can toggle on and off. For instance, let's say you would like to open the cart
 * drawer, whose id is "mini-cart", you simply need to retrieve it and set its "open" attribute to true (or
 * false to close it):
 *
 * document.getElementById('mini-cart').open = true;
 *
 * Thanks to the power of custom elements, the theme will take care automagically of trapping focus, maintaining
 * proper accessibility attributes...
 *
 * If you would like to create your own drawer, you can re-use the <drawer-content> content. Here is a simple
 * example:
 *
 * // Make sure you add "aria-controls", "aria-expanded" and "is" HTML attributes to your button:
 * <button type="button" is="toggle-button" aria-controls="id-of-drawer" aria-expanded="false">Open drawer</button>
 *
 * <drawer-content id="id-of-drawer">
 *   Your content
 * </drawer-content>
 *
 * The nice thing with custom elements is that you do not actually need to instantiate JavaScript yourself: this
 * is done automatically as soon as the element is inserted to the DOM.
 *
 * ------------------------------------------------------------------------------------------------------------
 * THEME DEPENDENCIES
 * ------------------------------------------------------------------------------------------------------------
 *
 * While the theme tries to keep outside dependencies as small as possible, the theme still uses third-party code
 * to power some of its features. Here is the list of all dependencies:
 *
 * "vendor.js":
 *
 * The vendor.js contains required dependencies. This file is loaded in parallel of the theme file.
 *
 * - custom-elements polyfill (used for built-in elements on Safari - v1.0.0): https://github.com/ungap/custom-elements
 * - web-animations-polyfill (used for polyfilling WebAnimations on Safari 12, this polyfill will be removed in 1 year - v2.3.2): https://github.com/web-animations/web-animations-js
 * - instant-page (v5.1.0): https://github.com/instantpage/instant.page
 * - tocca (v2.0.9); https://github.com/GianlucaGuarini/Tocca.js/
 * - seamless-scroll-polyfill (v2.0.0): https://github.com/magic-akari/seamless-scroll-polyfill
 *
 * "flickity.js": v2.2.0 (with the "fade" package). Flickity is only loaded on demand if there is a product image
 * carousel on the page. Otherwise it is not loaded.
 *
 * "photoswipe": v4.1.3. PhotoSwipe is only loaded on demand to power the zoom feature on product page. If the zoom
 * feature is disabled, then this script is never loaded.
 */

// saloni-open-first-menu-accordion
// $(document).on("click", '.header__icon-wrapper[aria-controls="mobile-menu-drawer"]', function() {
//   // $('.mobile-nav__item[data-level="1"]').find('button[aria-controls="mobile-menu-1"]').trigger("click");
//   $('.mobile-nav__item[data-level="1"]').find('button[aria-controls="mobile-menu-1"]').attr("aria-expanded", "true");
//   $('.mobile-nav__item[data-level="1"]').find('collapsible-content#mobile-menu-1').attr("open", "open");
//   $('.mobile-nav__item[data-level="1"]').find('collapsible-content#mobile-menu-1').css("overflow", "visible");
// });
// saloni-open-first-menu-accordion

// saloni-open-menu-by-footer-collection
$(document).on("click", ".footer__sticky-collection", function (e) {
  e.preventDefault();
  $(this)
    .parents("body")
    .find('.header__icon-wrapper[aria-controls="mobile-menu-drawer"]')
    .click();
});
// saloni-open-menu-by-footer-collection

// saloni-product
$(document).on("click", ".product-meta .jm-badge", function () {
  $("html,body").animate(
    {
      scrollTop: $("#judgeme_product_reviews").offset().top - 150,
    },
    "fast"
  );
});

$(document).on("click", ".active-offers-container .copy_code", function () {
  var temp = $("<input>");
  $("body").append(temp);
  temp.val($(this).prev().text()).select();
  document.execCommand("copy");
  temp.remove();
  let displayMsg = $(this).find(".tooltiptext");
  displayMsg.css("visibility", "visible");
  setTimeout(function () {
    displayMsg.css("visibility", "hidden");
  }, 1000);
});

$(document).on("click", "#read_more_desc", function () {
  if (screen.width <= 740) {
    $("#product-desc-trust-popover").attr("open", "open");
  } else {
    $("#product-desc-trust-drawer").attr("open", "open");
  }
});

$(document).on("click", "#view_all_ingredients", function () {
  if (screen.width <= 740) {
    $("#product-ingredients-trust-popover").attr("open", "open");
  } else {
    $("#product-ingredients-trust-drawer").attr("open", "open");
  }
});

$(document).on("click", "#read_more_faqs", function () {
  if (screen.width <= 740) {
    $("#product-faqs-trust-popover").attr("open", "open");
  } else {
    $("#product-faqs-trust-drawer").attr("open", "open");
  }
});

$(document).on(
  "click",
  ".product-sticky-form__payment-container .custom_qty_btn",
  function () {
    setTimeout(function () {
      let qty = $(".custom_qty").val();
      $(".product-form").find(".quantity-selector__input").val(qty);
    }, 300);
  }
);
// saloni-product

// saloni-tab-nav
const tabs_nav = document.querySelectorAll(
  ".tab-nav-container:not(.product-tab-nav) .tabs-nav__item"
);

tabs_nav.forEach((tab_nav) => {
  tab_nav.addEventListener("click", function (e) {
    e.preventDefault();
    let parentElm = tab_nav.closest(".tab-nav-container").classList;
    parentElm = String(parentElm).trim().replaceAll(" ", ".");
    let current_tabs_nav = document.querySelectorAll(
      "." + parentElm + " .tabs-nav__item"
    );
    current_tabs_nav.forEach((tabnav) => {
      tabnav.classList.remove("active");
    });
    this.classList.add("active");

    const href = this.getAttribute("href");
    const offsetTop = document.querySelector(href).offsetTop - 150;
    scroll({
      top: offsetTop,
      behavior: "smooth",
    });
  });
});
// saloni-tab-nav

// kishan tab nav with scroll + click
const links = document.querySelectorAll(
  ".product-tab-nav.tab-nav-container .tabs-nav__item"
);
window.addEventListener("scroll", navHighlighter);
window.addEventListener("load", navHighlighter);
window.addEventListener("resize", navHighlighter);
function navHighlighter() {
  const scrollY = window.pageYOffset;
  const headerHeight = document
    .querySelector("store-header")
    ?.getBoundingClientRect().height;
  if (event.type == "load") {
    const load_href = window.location.hash;
    if (load_href) {
      const load_offsetTop =
        document.querySelector(load_href)?.offsetTop -
        (57 + (headerHeight ? headerHeight : 85));
      load_offsetTop ? scroll({ top: load_offsetTop }) : null;
    }
    document
      .querySelector(".tab-nav-container")
      ?.closest(".shopify-section")
      .setAttribute("style", `top: ${headerHeight}px`);
  }
  if (links.length) {
    links.forEach((current) => {
      current.onclick = function (e) {
        const href = this.getAttribute("data-href");
        const offsetTop =
          document.querySelector(href).offsetTop -
          (57 + (headerHeight ? headerHeight : 85));
        scroll({
          top: offsetTop,
          behavior: "smooth",
        });
      };
      const section = document.querySelector(current.getAttribute("data-href"));
      const sectionHeight = section.offsetHeight;
      const sectionTop =
        section.offsetTop - (59 + (headerHeight ? headerHeight : 85));
      const linkID = current.getAttribute("data-href");
      if (scrollY >= sectionTop && scrollY <= sectionTop + sectionHeight) {
        document
          .querySelector(`a[data-href="${linkID}"]`)
          .classList.add("active");
      } else {
        document
          .querySelector(`a[data-href="${linkID}"]`)
          .classList.remove("active");
      }
    });
  }
}
// kishan tab nav with scroll + click

var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function () {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
      this.innerHTML = this.innerHTML.replace("&#9660;", "&#9650;");
    } else {
      panel.style.maxHeight = panel.scrollHeight + "10px";
      this.innerHTML = this.innerHTML.replace("&#9650;", "&#9660;");
    }
  });
}

// saloni-play-and-win
$("#shopify-section--play-and-win .logo-list__item").on("click", function () {
  let gameLink = $(this).find(".logo-list__item-link").text();
  if (gameLink) {
    var iframe =
      '<iframe width="100%" height="75%" src="' + gameLink + '"></iframe>';
    $("#game-launcher-popup").append(iframe);
    $("#game-launcher-popup").addClass("visible");
    $("html").css("overflow-y", "hidden");
    $("main#MainContent").addClass("custom-modal-opacity");
  } else {
    $(".close-game-popup").trigger("click");
  }
});

$(".close-game-popup").on("click", function () {
  $("#game-launcher-popup").removeClass("visible");
  $("html").css("overflow-y", "unset");
  $("main#MainContent").removeClass("custom-modal-opacity");
  $("#game-launcher-popup iframe").remove();
});
// saloni-play-and-win

// saloni-surprise-for-you
$(".surprise__button").on("click", function (e) {
  e.preventDefault();
  $(this)
    .parents(".surprise-for-you-popdraw")
    .find("header button")
    .trigger("click");
  $("#surprise-for-you-popup").addClass("visible");
  $("html").css("overflow-y", "hidden");
  $("main#MainContent").addClass("custom-modal-opacity");
});

$(".close-surprise-popup").on("click", function () {
  $("#surprise-for-you-popup").removeClass("visible");
  $("html").css("overflow-y", "unset");
  $("main#MainContent").removeClass("custom-modal-opacity");
});
// saloni-surprise-for-you

// saloni-newsletter-form
$(".newsletter-modal__form").on("submit", function (e) {
  const customerData = {
    tags: $('[name="contact[tags]"]').val(),
    email: $('[name="contact[email]"]').val(),
    phone: $('[name="contact[note][phone]"]').val(),
  };

  $.ajax({
    type: "POST",
    url: "https://gift.discoverpilgrim.com/polls/update_newsletter_customer",
    data: JSON.stringify(customerData),
    dataType: "json",
    success: function (data) {
      alert("Newsletter subscribed!");
      console.log(data);
    },
    error: function (err) {
      alert("Something went wrong. Please try again later!");
    },
  });
});
// saloni-newsletter-form

// saloni-product-card-variant-swatch
$(document).on("click", ".swatch-wrapper", function () {
  //.product-item-meta__swatch-list.color-swatch-list
  $(this)
    .parent()
    .next(".product-item__cta-wrapper")
    .find("button.product-item__cta")
    .trigger("click");
});
// saloni-product-card-variant-swatch

// saloni-corporate-gifting-scroll-to-callback-form
$(document).on(
  "click",
  ".corporate_gifting_kits .gallery__figure img",
  function () {
    let scrollToSection = $(this)
      .parents("#main")
      .find("section.corporate_gifting_callback_form");
    $("html,body").animate(
      {
        scrollTop: scrollToSection.offset().top - 100,
      },
      "fast"
    );
  }
);
// saloni-corporate-gifting-scroll-to-callback-form

// saloni-cart-drawer-open-quickview-drawer
$(document).on(
  "click",
  "quick-buy-drawer .product-form .product-form__add-button",
  function () {
    $("quick-buy-drawer").find(".drawer__close-button").trigger("click");
    $('.header__icon-wrapper[aria-controls="mini-cart"]').attr(
      "aria-expanded",
      "true"
    );
  }
);
// saloni-cart-drawer-open-quickview-drawer

// saloni-change-variant-price-on quick-buy
// $(document).on("click", ".quick-buy-popover-content .color-swatch__radio, .quick-buy-drawer-content .color-swatch__radio", function() {
//   let variantPrice = $(this).attr("variant-price");
//   let variantComparePrice = $(this).attr("variant-compare-price");
//   $(".quick-buy-popover-content .price-list").find("span.price.price--highlight").text(variantPrice);
//   $(".quick-buy-drawer-content .price-list").find("span.price.price--highlight").text(variantPrice);

//   if(variantComparePrice) {
//     $(".quick-buy-popover-content .price-list").find("span.price.price--compare").text(variantComparePrice).show();
//     $(".quick-buy-drawer-content .price-list").find("span.price.price--compare").text(variantComparePrice).show();
//     variantPrice = variantPrice.replace("₹", "").replace(",", "").split(".");
//     variantComparePrice = variantComparePrice.replace("₹", "").replace(",", "").split(".");
//     variantPrice = Number(variantPrice[0]);
//     variantComparePrice = Number(variantComparePrice[0]);
//     let variantDiscountPercent = ((variantComparePrice - variantPrice) * 100) / variantComparePrice;
//     variantDiscountPercent = Math.round(variantDiscountPercent);
//     $(".quick-buy-popover-content .price-list").find("span.discount-percentage").text("("+variantDiscountPercent+"% OFF)").show();
//     $(".quick-buy-drawer-content .price-list").find("span.discount-percentage").text("("+variantDiscountPercent+"% OFF)").show();
//   } else {
//     $(".quick-buy-popover-content .price-list").find("span.price.price--compare").hide();
//     $(".quick-buy-drawer-content .price-list").find("span.price.price--compare").hide();
//     $(".quick-buy-popover-content .price-list").find("span.discount-percentage").hide();
//     $(".quick-buy-drawer-content .price-list").find("span.discount-percentage").hide();
//   }
// });
// saloni-change-variant-price-on quick-buy

// saloni-on-change-skintone-filter
$(document).on("click", ".skintone-tab-nav .tabs-nav__item", function () {
  let skintone = $(this).attr("skintone");
  let currentVar = "{{ current_variant.title }}";
  let altText = currentVar + "_" + skintone;

  $(".skintone_images").each(function () {
    $(this).css("display", "none");
  });

  if ($(".skintone_image_wrapper").find("#" + skintone).length == 0) {
    $(".skintone_image_wrapper").find("#None").css("display", "block");
  } else {
    $("#" + skintone).css("display", "block");
  }
});
// saloni-on-change-skintone-filter

// kishan change variant on makeup product
// if(document.querySelector('body.product_variantfilter')){
//   document.addEventListener('variant:changed', function(evt) {
//     let allVariantSelector = document.querySelectorAll('variant-picker');
//     if(allVariantSelector.length){
//       allVariantSelector.forEach(selector=>{
//         if(evt.detail.variant.id != selector.selectedVariant.id){
//           evt.detail.variant.options.forEach(value=>{
//             selector.querySelector('[value="'+ value +'"]').checked = true;
//             selector.querySelector('[value="'+ value +'"]').dispatchEvent(new Event('change', { bubbles: true,  cancelable: true }));
//           });
//           selector.classList.contains('variants_wrapper')?document.querySelector('.product_filters [data-variant-names="All"]')?.click():null;
//         }
//       })
//     }
//   })
// }
// kishan change variant on makeup product

// saloni-change-variant-on-product-page
$(document).on("change", ".color-swatch__radio", function (e) {
  $(".product-form__variants")
    .find('.color-swatch__radio[value="' + $(this).val() + '"]')
    .trigger("click");
  setTimeout(function () {
    let checkedElement = $(
      ".shopify-section--main-product input.color-swatch__radio:checked"
    );
    let light_skintone_image = checkedElement
      .prev()
      .attr("light_skintone_image");
    let medium_skintone_image = checkedElement
      .prev()
      .attr("medium_skintone_image");
    let deep_skintone_image = checkedElement.prev().attr("deep_skintone_image");
    let no_skintone_image = checkedElement.prev().attr("no_skintone_image");
    let variant_subtitle = checkedElement.prev().attr("variant_subtitle");
    let variant_title = checkedElement.prev().text();

    $(".try-our-filter-section .product-form__option-value").text(
      variant_title
    );
    $(".variant-subtitle").text(variant_subtitle);

    if (light_skintone_image && medium_skintone_image && deep_skintone_image) {
      $(".skintone_images.light_skintone_image img").attr(
        "src",
        light_skintone_image
      );
      $(".skintone_images.medium_skintone_image img").attr(
        "src",
        medium_skintone_image
      );
      $(".skintone_images.deep_skintone_image img").attr(
        "src",
        deep_skintone_image
      );
    } else if (no_skintone_image) {
      $(".skintone_images.no_skintone_image img").attr(
        "src",
        no_skintone_image
      );
    }
  }, 50);
});
// saloni-change-variant-on-product-page

// saloni-change-quantity-on-product-page
$(".product-form .custom_qty_btn").on("click", function () {
  let thisEle = $(this)
    .parent(".quantity-selector")
    .find(".quantity-selector__input.custom_qty");
  setTimeout(function () {
    $(".product-form").find(".quantity-selector__input").val(thisEle.val());
    $(".product-sticky-form__payment-container")
      .find(".quantity-selector__input")
      .val(thisEle.val());
  }, 300);
});
// saloni-change-quantity-on-product-page

// saloni-open-newsletter-popup-on-banner-click
$(document).on("click", ".banner_newsletter", function () {
  $('button[aria-controls="newsletter-popup"]').trigger("click");
});
// saloni-open-newsletter-popup-on-banner-click

// saloni-order-limiter
(function (ns, fetch) {
  if (typeof fetch !== "function") return;
  ns.fetch = function () {
    const response = fetch.apply(this, arguments);
    response.then((res) => {
      if ([`${window.location.origin}/cart/change.js`].includes(res.url)) {
        res
          .clone()
          .json()
          .then((cart) => {
            if (cart.status == 422) {
              $("cart-drawer .cart-notification").removeAttr("hidden");
              $("cart-drawer .cart-notification")
                .find("span.cart-notification__heading")
                .text(cart.message);
            }
          });
      }
    });
    return response;
  };
})(window, window.fetch);

// document.addEventListener('cart:updated', function(event) {
//   var cart = event.detail.cart;
//   if(cart.status == 422) {
//     $("cart-drawer .cart-notification").removeAttr("hidden");
//     $("cart-drawer .cart-notification").find("span.cart-notification__heading").text(cart.message);
//   }
// });
// saloni-order-limiter

// kishan slideshow swipable code
let allSlide = document.querySelectorAll(
  ".swipeable_slideshow slide-show-item"
);
if (allSlide.length) {
  let dots = document.querySelectorAll(
    ".swipeable_slideshow page-dots > button"
  );
  let scrollLeft = allSlide[1].offsetLeft - allSlide[0].offsetLeft;
  document
    .querySelector(".swipeable_slideshow page-dots")
    .addEventListener("page-dots:changed", function (event) {
      let leftValue = allSlide[event.detail.index].offsetLeft;
      document
        .querySelector(".swipeable_slideshow .slideshow__slide-list")
        .scrollTo(leftValue, 0);
    });
  function slideChange(e, startpoint, endpoint) {
    if (endpoint > startpoint) {
      let leftValue =
        e.target.closest("slide-show-item")?.previousElementSibling.offsetLeft;
      document
        .querySelector(".swipeable_slideshow .slideshow__slide-list")
        .scrollTo(leftValue, 0);
      dots[Math.round(leftValue / scrollLeft)]?.click();
    } else {
      let leftValue =
        e.target.closest("slide-show-item")?.nextElementSibling.offsetLeft;
      document
        .querySelector(".swipeable_slideshow .slideshow__slide-list")
        .scrollTo(leftValue, 0);
      dots[Math.round(leftValue / scrollLeft)]?.click();
    }
  }
  if (screen.width >= 600) {
    let ds;
    document
      .querySelector(".swipeable_slideshow .slideshow__slide-list")
      ?.addEventListener("dragstart", (e) => {
        ds = e.pageX;
      });
    document
      .querySelector(".swipeable_slideshow .slideshow__slide-list")
      ?.addEventListener("dragend", (e) => {
        let de = e.pageX;
        slideChange(e, ds, de);
      });
  } else {
    let ts;
    document
      .querySelector(".swipeable_slideshow .slideshow__slide-list")
      ?.addEventListener("touchstart", function (event) {
        ts = event.touches[0].clientX;
      });
    document
      .querySelector(".swipeable_slideshow .slideshow__slide-list")
      ?.addEventListener("touchend", function (event) {
        let te = event.changedTouches[0].clientX;
        slideChange(event, ts, te);
      });
  }
}
// kishan slideshow swipable code

// kishan product variant filter code
if (document.querySelector(".product_variantfilter")) {
  // Function to handle the added element
  let allFilters = document.querySelectorAll(".product_filters > li > a");

  // Function to handle the hideVariant functionality
  function hideVariant(link, firstLoad) {
    const variantArray = link.dataset.variantNames.split("|").filter(Boolean);
    let allSwatches = link
      .closest(".product_filters")
      .parentElement.querySelectorAll(
        ".variants_wrapper .color-swatch-list > div > input, .variants_wrapper .variant-swatch-list > div > input, .variants_wrapper .block-swatch-list > div > input"
      );
    allSwatches.forEach((item) => item.parentElement.classList.add("hide"));
    variantArray.forEach((variantName) => {
      const variantInnerArray = variantName.split("/");
      variantInnerArray.forEach((variantN) => {
        allSwatches.forEach((item) => {
          if (item.dataset.optionValue.trim() == variantN.trim())
            item.parentElement.classList.remove("hide");
        });
      });
    });
    allFilters.forEach((linkIn) => linkIn.classList.remove("active"));
    link.classList.add("active");
    const visibleSwatch = link
      .closest(".product_filters")
      .nextElementSibling.querySelectorAll(
        ".variants_wrapper .color-swatch-list > div:not(.hide) > label, .variants_wrapper .variant-swatch-list > div:not(.hide) > label"
      );
    if (!firstLoad) visibleSwatch.length && visibleSwatch[0].click();
  }

  // Function to handle the click event on filters
  function handleFilterClick(link) {
    if (link.dataset.variantNames === "All") {
      let allSwatches = link
        .closest(".product_filters")
        .parentElement.querySelectorAll(
          ".variants_wrapper .color-swatch-list > div > input, .variants_wrapper .variant-swatch-list > div > input, .variants_wrapper .block-swatch-list > div > input"
        );
      allSwatches.forEach((item) =>
        item.parentElement.classList.remove("hide")
      );
      allFilters.forEach((linkIn) => linkIn.classList.remove("active"));
      link.classList.add("active");
    } else {
      hideVariant(link);
    }
  }

  // Add click event listeners to all filters
  allFilters.forEach((link) => {
    link.addEventListener("click", () => handleFilterClick(link));
    if (
      link.classList.contains("active") &&
      link.dataset.variantNames !== "All"
    )
      hideVariant(link, true);
  });

  // Create a MutationObserver to handle future mutations
  const observer = new MutationObserver((mutationsList) => {
    mutationsList.forEach((mutation) => {
      const addedNodes = Array.from(mutation.addedNodes).filter(
        (node) => node instanceof Element
      );
      addedNodes.forEach((node) => {
        let variantsWrapper = node;
        if (
          variantsWrapper.classList.contains("variants_wrapper") ||
          variantsWrapper.querySelector(".variants_wrapper")
        ) {
          variantsWrapper.addEventListener("variants_wrapper", () => {
            allFilters = document.querySelectorAll(".product_filters > li > a");
            allFilters.forEach((link) => {
              link.addEventListener("click", () => handleFilterClick(link));
              if (
                link.classList.contains("active") &&
                link.dataset.variantNames !== "All"
              )
                hideVariant(link, true);
            });
          });
          variantsWrapper.dispatchEvent(new Event("variants_wrapper"));
        }
      });
    });
  });

  // Start observing the document body for changes
  observer.observe(document.body, { childList: true, subtree: true });
}
// kishan product variant filter code

// copy coupon code functionality
document.addEventListener("click", function (event) {
  if (event.target.classList.contains("copy-btn")) {
    let text = event.target
      .closest(".offer_banner")
      .querySelector(".copy-text").innerHTML;
    let textarea = document.createElement("textarea");
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    document.body.removeChild(textarea);
  }
});

// PD page media zoom close button
document.addEventListener("click", (e) => {
  if (
    e.target.classList.contains("pswp__button--close") ||
    e.target.closest("product-image-zoom")
  ) {
    setTimeout(() => {
      e.target.closest("product-image-zoom").classList.remove("pswp--open");
    }, 500);
  }
});

// add to cart sticky form people bought lable js
function showLable() {
  let stickyform = document.querySelector("product-sticky-form");
  if (stickyform) {
    if (stickyform.getAttribute("hidden") == null) {
      setTimeout(() => {
        stickyform.querySelector(".people-bought")?.classList.add("show");
      }, 500);
    }
  }
}
showLable();
document.addEventListener("htmlRendered", () => {
  showLable();
});
document.addEventListener("scroll", (e) => {
  showLable();
});

// 21-08-24 Yash milestone, upvote

// saloni-upvote-newsletter
$(document).on("click", "#upvoteSlideButton", function () {
  document.getElementById("newsletter-upvote-popup").open = true;
});

$(document).on(
  "click",
  '.newsletter-upvote-modal__form button[type="submit"]',
  function (e) {
    let upvoteTags = $(".newsletter-upvote-modal__form")
      .find('[name="contact[tags]"]')
      .val();
    let upvoteEmail = $(".newsletter-upvote-modal__form")
      .find('[name="contact[email]"]')
      .val();
    let upvotePhone = $(".newsletter-upvote-modal__form")
      .find('[name="contact[note][phone]"]')
      .val();

    const customerData = {
      tags: upvoteTags,
      email: upvoteEmail,
      phone: upvotePhone,
    };

    sessionStorage.setItem("upvote-popup", "true");

    if (upvoteEmail && upvotePhone) {
      $.ajax({
        type: "POST",
        url: "https://gift.discoverpilgrim.com/polls/update_newsletter_customer",
        data: JSON.stringify(customerData),
        dataType: "json",
        success: function (data) {
          // alert("Thanks for voting!");
        },
        error: function (err) {
          if (err.status != 0) {
            alert("Something went wrong. Please try again later!");
          }
        },
      });
    } else {
      e.preventDefault();
      if (upvoteEmail === "") {
        $(".newsletter-upvote-modal__form")
          .find('[name="contact[email]"]')
          .addClass("invalid");
      } else if (upvotePhone === "") {
        $(".newsletter-upvote-modal__form")
          .find('[name="contact[note][phone]"]')
          .addClass("invalid");
      }
    }
  }
);
// saloni-upvote-newsletter

// yash-upvote-feature
const upvoteButtonsCard = document.querySelectorAll(".upvote-product-card");
upvoteButtonsCard[0].innerHTML +=
  '<img class="badge_image" src="https://cdn.shopify.com/s/files/1/0620/1629/1045/files/Gold_badge_1.png?v=1724094293">';
upvoteButtonsCard[1].innerHTML +=
  '<img class="badge_image" src="https://cdn.shopify.com/s/files/1/0620/1629/1045/files/Silver_badge_2.png?v=1724094294">';
upvoteButtonsCard[2].innerHTML +=
  '<img class="badge_image" src="https://cdn.shopify.com/s/files/1/0620/1629/1045/files/Bronze_badge_3.png?v=1724094294">';

// vote count based on timestamp function
function updateVotes() {
  let timestamp = Math.floor(Date.now() / 10000 - 172424000);
  const voteElements = document.querySelectorAll(".upvote-product-card-vote");

  voteElements[0].textContent =
    Math.floor(parseInt(voteElements[0].textContent) + timestamp - 2000 / 100) +
    " votes";
  voteElements[1].textContent =
    Math.floor(parseInt(voteElements[1].textContent) + timestamp - 3000 / 100) +
    " votes";
  voteElements[2].textContent =
    Math.floor(parseInt(voteElements[2].textContent) + timestamp - 4020 / 100) +
    " votes";
  voteElements[3].textContent =
    Math.floor(parseInt(voteElements[3].textContent) + timestamp - 9544 / 100) +
    " votes";
  voteElements[4].textContent =
    Math.floor(parseInt(voteElements[4].textContent) + timestamp - 10000 / 100) +
    " votes";
  voteElements[5].textContent =
    Math.floor(parseInt(voteElements[5].textContent) + timestamp - 12000 / 100) +
    " votes";
  voteElements[6].textContent =
    Math.floor(parseInt(voteElements[6].textContent) + timestamp - 15500 / 100) +
    " votes";
  voteElements[7].textContent =
    Math.floor(parseInt(voteElements[7].textContent) + timestamp - 17000 / 100) +
    " votes";
  voteElements[8].textContent =
    Math.floor(parseInt(voteElements[8].textContent) + timestamp - 50000 / 100) +
    " votes";
  voteElements[9].textContent =
    Math.floor(parseInt(voteElements[9].textContent) + timestamp - 60000 / 100) +
    " votes";
  voteElements[10].textContent =
    Math.floor(
      parseInt(voteElements[10].textContent) + timestamp - 90000 / 100
    ) + " votes";
  voteElements[11].textContent =
    Math.floor(
      parseInt(voteElements[11].textContent) + timestamp - 100000 / 100
    ) + " votes";
}

updateVotes();

document.addEventListener("DOMContentLoaded", function () {
  const upvoteButtons = document.querySelectorAll(".upvote-vote-button");

  upvoteButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const productCard = this.closest(".upvote-product-card");
      const productTitle = productCard.querySelector(
        ".upvote-product-card-title"
      ).textContent;
      const upvoteCount = productCard.querySelector(
        ".upvote-product-card-vote"
      ).textContent;
      const getProductCount = productCard.querySelector(".upvote-vote-button")
        .dataset.productnumber;
      upvoteCount.textContent = parseInt(upvoteCount) + 1 + " votes";

      let updated_count = parseInt(upvoteCount) + 1;
      let upvoted_sucessfully = sessionStorage.getItem("upvoted_sucessfully");
      if (upvoted_sucessfully !== "true") {
        sessionStorage.setItem("upvoted-product-name", productTitle);
        sessionStorage.setItem("upvoted-product-vote", updated_count);
        sessionStorage.setItem("upvoted-product-index", getProductCount);
      }
      if (upvoted_sucessfully === "true") {
        document.querySelector(".upvoteSlide_vote_count").textContent = "";
      }
    });
  });
});

//after submitting vote function
const submitedVoteFlag = sessionStorage.getItem("upvote-popup");
const upvoted_sucessfully = sessionStorage.getItem("upvoted_sucessfully");
if (submitedVoteFlag === "true") {
  document.querySelectorAll(".upvote-vote-button").forEach((button) => {
    document.getElementById("upvote_form_content")
      ? (document.getElementById("upvote_form_content").style.display = "none")
      : "";
    document.getElementById("upvote_sucess_content")
      ? (document.getElementById("upvote_sucess_content").style.display =
          "block")
      : "";
    let upvotedProductName = sessionStorage.getItem("upvoted-product-name");
    document.querySelector(".upvoteSlide_vote_text_title").textContent =
      upvotedProductName;
    document.querySelector(".upvoteSlide_vote_text_title_share").textContent =
      upvotedProductName;
    //getting product index
    let upvoted_product_index = sessionStorage.getItem("upvoted-product-index");
    let upvoteButtons = document.querySelectorAll(".upvote-vote-button");
    upvoteButtons[
      upvoted_product_index - 1
    ].innerHTML = `<span class="pvoteSlideButton_text"> Voted</span>`;
    upvoteButtons[upvoted_product_index - 1].style.backgroundColor =
      "rgb(56 142 60 / 50%)";
    // optional on second click remove vote
    // if (upvoted_sucessfully_vote_remove === true) {
    //   const olderVoteRemove = document.getElementById('upvoteSlide_vote_count');
    //   olderVoteRemove.remove();
    // }
  });
}

// yash-upvote-feature end

// yash-sticky-notes / appreciation wall start
//  scroll Animation
document.addEventListener("DOMContentLoaded", function () {
  const board = document.getElementById("board");
  const section = document.querySelector("#board"); // Select your section
  let previousScrollPosition = window.pageYOffset;

  // Intersection Observer to detect when the section is in the viewport
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          // When the section is visible, add the scroll event listener
          window.addEventListener("scroll", handleScroll);
        } else {
          // When the section is not visible, remove the scroll event listener
          window.removeEventListener("scroll", handleScroll);
        }
      });
    },
    { threshold: 0.5 }
  ); // Adjust the threshold to 0.5 (50% visible)

  observer.observe(section);

  function handleScroll() {
    let currentScrollPosition = window.pageYOffset;
    let scrollAmount = 1; // Slower scroll amount

    if (currentScrollPosition > previousScrollPosition) {
      // Scrolling down
      smoothScroll(board, board.scrollTop + scrollAmount);
      setTimeout(() => {
        smoothScroll(board, board.scrollTop + scrollAmount);
      }, 350);
    } else {
      // Scrolling up
      smoothScroll(board, board.scrollTop - scrollAmount);
      setTimeout(() => {
        smoothScroll(board, board.scrollTop - scrollAmount);
      }, 350);
    }
    previousScrollPosition = currentScrollPosition;
  }

  // Smooth scrolling function
  function smoothScroll(element, targetPosition) {
    element.style.transition = "scroll-top 1s ease-out";
    element.scrollTop = targetPosition;
  }
});

// update message after sbmitting the form
function updatemessage() {
  const userMessageElement = document.querySelector(
    "#bord_message .user_message"
  );
  const userNameElement = document.querySelector("#bord_message .user_name");

  const userMessage = document.getElementById("user-message").value.trim();
  const userName = document.getElementById("user-name").value.trim();

  if ((userMessageElement.textContent = userMessage)) {
    userNameElement.textContent = userName || "Your name...";
  } else {
    userNameElement.textContent = userName || "";
    userMessageElement.textContent = userMessage || "Your message...";
  }
  userMessageElement.textContent = userMessage || "Your message...";
}
document.addEventListener("DOMContentLoaded", function () {
  const scriptURL =
    "https://script.google.com/macros/s/AKfycbz-NAbJYdPQMonWIF-plprSvd4YpDCZ5AMthT1unPM6cAr8qbbYi8Pwvo4izer50nOh/exec";
  const gradients = [
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/confetti-ball_1f38a.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/partying-face_1f973.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/birthday-cake_1f382.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/mirror-ball_1faa9.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/wrapped-gift_1f381_1.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/confetti-ball_1f38a.gif?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/wrapped-gift_1f381.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/balloon_1f388.gif?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/clinking-glasses_1f942.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/bottle-with-popping-cork_1f37e.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/shortcake_1f370.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/party-popper_1f389.png?v=1724229685",
    "https://cdn.shopify.com/s/files/1/0620/1629/1045/files/mirror-ball_1faa9_1.png?v=1724241584",
  ];

  function loadNewMessages(newMessage) {
    const newUserMessage = document.getElementById("bord_message");
    const message_form = document.getElementById("message-form");
    newUserMessage.innerHTML = "";
    message_form.innerHTML = ` <div class="user-message-container"><div class="user-message-sucess">Thanks for the birthday wishes!</div>
<img src="https://cdn.shopify.com/s/files/1/0620/1629/1045/files/tick_cross.svg?v=1722927062" alt="Happy Birthday" style="width: 20px;"/></div>`;
    newUserMessage.removeAttribute("id");
    newUserMessage.remove;
    const newUserMessageContent = `<div class="sticky-container" id="sticky-8">
                 <div class="sticky-content" >
                <div class="sticky-content_container" style="
                  display: flex;
                  justify-content: space-around;
                  align-items: center;
                  gap: 10px;
                  align-content: flex-start;
                ">
                <img class="sticky_emoji" src="https://cdn.shopify.com/s/files/1/0620/1629/1045/files/birthday-cake_1f382.gif?v=1724229687" />
                <div class="sticky-content_container_message_box">
                <p class="sticky-message" style="margin-bottom: 2px;">
                ${newMessage.message}
                </p>
                <p class="sticky-message" style="font-weight: 700;margin-top: 0 !important;">
                 - ${newMessage.name}
                </p>
              </div>
              </div>
                  </div>
            </div>`;
    document
      .getElementById("board")
      .insertAdjacentHTML("beforeend", newUserMessageContent);
  }
  function shuffleGradients(array) {
    let currentIndex = array.length;
    while (currentIndex != 0) {
      let randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex],
        array[currentIndex],
      ];
    }
  }
  shuffleGradients(gradients);
  function loadMessages(newMessage) {
    fetch(scriptURL)
      .then((response) => response.json())
      .then((messages) => {
        messages.forEach((msg, index) => {
          if (msg.show === true) {
            document.getElementById("board").innerHTML += `
            <div class="sticky-container" id="sticky-${index}">
                 <div class="sticky-content" >
                <div class="sticky-content_container" style="
                  display: flex;
                  justify-content: space-around;
                  align-items: center;
                  gap: 10px;
                  align-content: flex-start;
                ">
                <img class="sticky_emoji" src="${gradients[index]}" />
                <div class="sticky-content_container_message_box">
                <p class="sticky-message" style="margin-bottom: 2px;">
                ${msg.message}
                </p>
                <p class="sticky-message" style="font-weight: 700;margin-top: 0 !important;">
                 - ${msg.name}
                </p>
              </div>
              </div>
                  </div>
            </div>`;
          }
        });
      })
      .catch((error) => {
        console.error("Error loading messages:", error);
        const staticMessages = [
          {
            name: "Kishan",
            message: "Happy birthday Pilgrim, love your products! 🎂🍾",
            show: true,
          },
          { name: "Sai", message: "Happiest birthday pilgrim💕", show: true },
          {
            name: "Yash",
            message: "Happy birthday Pilgrim, love your products! 🎂🍾",
            show: true,
          },
          {
            name: "Saloni",
            message:
              "Wishing you a successful year ahead, may you be graced with good work and goals🎁",
            show: true,
          },
          {
            name: "Deepak",
            message:
              "Happy birthday 🥳 May your birthday usher in a year of good fortune",
            show: true,
          },
          { name: "Shashank", message: "Happy birthday pilgrim", show: true },
        ];

        staticMessages.forEach((msg, index) => {
          const randomGradient =
            gradients[Math.floor(Math.random() * gradients.length)];
          document.getElementById("board").innerHTML += `
      <div class="sticky-container" id="sticky-${index}">
                 <div class="sticky-content" >
                <div class="sticky-content_container" style="
                  display: flex;
                  justify-content: space-around;
                  align-items: center;
                  gap: 10px;
                  align-content: flex-start;
                ">
                <img class="sticky_emoji" src="${gradients[index]}" />
                <div class="sticky-content_container_message_box">
                <p class="sticky-message" style="margin-bottom: 2px;">
                ${msg.message}
                </p>
                <p class="sticky-message" style="font-weight: 700;margin-top: 0 !important;">
                 - ${msg.name}
                </p>
              </div>
              </div>
                  </div>
            </div>`;
        });
      });
  }

  loadMessages();

  document
    .getElementById("message-form")
    .addEventListener("submit", function (event) {
      event.preventDefault();
      const userName = document.getElementById("user-name").value;
      const userMessage = document.getElementById("user-message").value;
      if (userName && userMessage) {
        const newMessage = { name: userName, message: userMessage };
        fetch(scriptURL, {
          method: "POST",
          mode: "no-cors",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newMessage),
        })
          .then((response) => response)
          .then((response) => {
            loadNewMessages(newMessage);
            document.getElementById("user-name").value = "";
            document.getElementById("user-message").value = "";
            newMessage["show"] = true;
            // loadMessages(newMessage);
          })
          .catch((error) => {
            console.error("Error submitting message:", error);
          });
      }
    });
});
// yash-sticky-notes / appreciation wall
