var product_map = {
  '7768274469093': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7774893277413': {
    'frequency': 'Daily',
    'function': 'Tone',
    'sub_step': null
  },
  '7774893375717': {
    'frequency': 'Weekly',
    'function': 'Exfloliation',
    'sub_step': null
  },
  '7774893474021': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774893506789': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774898127077': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774897930469': {
    'frequency': 'Weekly',
    'function': 'Masking',
    'sub_step': null
  },
  '7774897897701': {
    'frequency': 'Daily',
    'function': 'Tone',
    'sub_step': null
  },
  '7774897799397': {
    'frequency': 'Weekly',
    'function': 'Exfloliation',
    'sub_step': null
  },
  '7774897733861': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7774898159845': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774897996005': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Eye cream'
  },
  '7774895210725': {
    'frequency': 'Weekly',
    'function': 'Exfloliation',
    'sub_step': null
  },
  '7774894358757': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774893998309' :{
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774894194917': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Eye cream'
  },
  '7774894457061': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774894555365': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774894588133': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774894653669': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774894883045': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7774894817509': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7774895276261': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774895309029': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774895440101': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774895472869': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7774894948581': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774895669477': {
    'frequency': 'Weekly',
    'function': 'Masking',
    'sub_step': null
  },
  '7774895735013': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774895767781': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774898487525': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7774898553061': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774900125925': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7774899699941': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774899405029': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7662692008165': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774899765477': {
    'frequency': 'Daily',
    'function': 'Masking',
    'sub_step': null
  },
  '7663310635237': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Eye cream'
  },
  '7774899601637': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  },
  '7774899503333': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7774899568869': {
    'frequency': 'Daily',
    'function': 'Tone',
    'sub_step': null
  },
  '7774899863781': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Eye cream'
  },
  '7859213500645': {
    'frequency': 'Daily',
    'function': 'Protect',
    'sub_step': null
  },
  '7859213533413': {
    'frequency': 'Daily',
    'function': 'Protect',
    'sub_step': null
  },
  '7916360040677': {
    'frequency': 'Daily',
    'function': 'Protect',
    'sub_step': null
  },
  '7969737605349': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7969737572581': {
    'frequency': 'Daily',
    'function': 'Cleanse',
    'sub_step': null
  },
  '7969737539813': {
    'frequency': 'Daily',
    'function': 'Tone',
    'sub_step': null
  },
  '7969737507045': {
    'frequency': 'Daily',
    'function': 'Moisturize',
    'sub_step': null
  },
  '7969737441509': {
    'frequency': 'Daily',
    'function': 'Treat',
    'sub_step': 'Face serum'
  }
};

var three_step = ['Cleanse','Treat','Moisturize'];
var five_step = ['Cleanse', 'Treat','Moisturize', 'Tone','Protect'];
