// saloni-rachet-cart-drawer
setTimeout(function() {
  $(".scd__footer").appendTo(".checkout-form");
}, 2000);

const enable_upsell_slider = "false";
const upsell_collection = "upsell";
if(enable_upsell_slider == "true" && upsell_collection != "") {
  async function getAtcCartData() {
    var cart;
    $.getJSON('/cart.js', function(cart){
      Shopify.onCartUpdate(cart);
    });
  }

  async function addAtcProduct(product_id) {
    let op_id;
    $(".scd-item").each(function() {
      let categories = $(this).attr("data-category");
      let id = $(this).attr("data-variant-id");
      categories = categories.split(", ");
      $.each(categories,function(i){
        if(categories[i] == upsell_collection) {
          op_id = id;
          return false;
        }
      });
      if(op_id) {
        $(".cart-loader").css("display", "none");
        $(".scd__footer .sf__btn.sf__btn-primary").removeClass("disabled disabled-po");
        $(".scd__footer .sf__btn.sf__btn-primary").removeAttr("disabled");
        return false;
      } else {
        const addAtcVariant = {
          id: product_id,
          quantity: 1
        };
        $.ajax({
          type: 'POST',
          url: '/cart/add.js',
          dataType: 'json',
          data: addAtcVariant,
          success: function(cart){
            Shopify.onCartUpdate(cart);
            $(".cart-loader").css("display", "none");
            $(".scd__footer .sf__btn.sf__btn-primary").removeClass("disabled disabled-po");
            $(".scd__footer .sf__btn.sf__btn-primary").removeAttr("disabled");
          },
          error: function(){}
        });
      }
    });
  }

  async function removeAtcProduct(newCartTotal) {
    let min_cart_value = '749';
    let max_cart_value = '100000';
    let upsell_collection = 'upsell';
    setTimeout(function() {
      let product_id = [], op_price = 0;
      $(".scd-item").each(function() {
        let categories = $(this).attr("data-category");
        let id = $(this).attr("data-variant-id");
        let pprice = $(this).find(".scd-item__price").text().replace(",","");
        categories = categories.split(", ");
        $.each(categories,function(i){
          if(categories[i] == upsell_collection) {
            product_id.push(id);
            op_price = pprice.split("₹")[1];
            return false;
          }
        });
        // if(product_id) {
        //   return false;
        // }
      });

      newCartTotal = Number(newCartTotal) - Number(op_price);
      if((newCartTotal < min_cart_value) || (newCartTotal > max_cart_value)) {
        for(let id of product_id) {
          const removeAtcVariant = {
            id: id,
            quantity: 0
          };
  
          $.ajax({
            type: 'POST',
            url: '/cart/change.js',
            dataType: 'json',
            async: false,
            data: removeAtcVariant,
            success: function(cart){
              Shopify.onCartUpdate(cart);
            },
            error: function(){}
          });
        }
      }
      $(".cart-loader").css("display", "none");
      $(".scd__footer .sf__btn.sf__btn-primary").removeClass("disabled disabled-po");
    }, 1000);
  }
  
  $(document).on("click", ".ops-add-to-cart", function() {
    $(".cart-loader").css("display", "block");
    $(".scd__footer .sf__btn.sf__btn-primary").addClass("disabled disabled-po");
    $(".scd__footer .sf__btn.sf__btn-primary").attr("disabled", "disabled");
    const atc_product_id = $(this).parents(".sf__pcard").find('input[name="id"]').val();
    addAtcProduct(atc_product_id);
    $(".cart-offer-slider").css("display", "none");
  });

  $(document).on("change", ".scd-item__qty_input", function() {
    $(".cart-loader").css("display", "block");
    $(".scd__footer .sf__btn.sf__btn-primary").addClass("disabled disabled-po");
    let variant_id = $(this).prev().attr("data-variant_id");
    let variant_qty = $(this).val();
    removeAtcProduct(variant_id, variant_qty);
  });

  $(document).on("click", 'button.scd-item__remove', function() {
    $(".cart-loader").css("display", "block");
    $(".scd__footer .sf__btn.sf__btn-primary").addClass("disabled disabled-po");
    let variant_id = $(this).attr("data-variant_id");
    let variant_qty = $(this).closest(".scd-item__info").find(".scd-item__qty_input").val();

    setTimeout(function(){
      $.ajax({
        type: 'GET',
        url: '/cart.json',
        dataType: 'json',
        success: function(result) {
          let total_price = result.total_price;

          let item_exist = false, item_qty = 0;
          for (const i of result.items) {
            if(i.id == variant_id) {
              item_exist = true;
              item_qty = i.quantity;
              break;
            }
          }

          if(item_exist) {
            const removeVariant = {
              id: variant_id,
              quantity: 0
            };
            
            $.ajax({
              type: 'POST',
              url: '/cart/change.js',
              dataType: 'json',
              data: removeVariant,
              async: false,
              success: function(cart){
                newCartTotal = cart.total_price / 100;
                Shopify.onCartUpdate(cart);
                removeAtcProduct(newCartTotal);
              },
              error: function(){}
            });
          } else {
            newCartTotal = total_price / 100;
            removeAtcProduct(newCartTotal);
          }
        },
        error: function() {
          alert("Something went wrong. Please try again later!");
        }
      });
    }, 2000);
  });

  $(document).on("click", 'button[data-qty-change="dec"]', function() {
    $(".cart-loader").css("display", "block");
    $(".scd__footer .sf__btn.sf__btn-primary").addClass("disabled disabled-po");
    let variant_id = $(this).attr("data-variant_id");
    let variant_qty = $(this).closest(".scd-item__info").find(".scd-item__qty_input").val();

    setTimeout(function(){
      $.ajax({
        type: 'GET',
        url: '/cart.json',
        dataType: 'json',
        success: function(result) {
          let total_price = result.total_price;

          let item_exist = false, item_qty = 0;
          for (const i of result.items) {
            if(i.id == variant_id) {
              item_exist = true;
              item_qty = i.quantity;
              break;
            }
          }

          if(item_exist) {
            if(item_qty == variant_qty) {
              const removeVariant = {
                id: variant_id,
                quantity: variant_qty - 1
              };
              
              $.ajax({
                type: 'POST',
                url: '/cart/change.js',
                dataType: 'json',
                data: removeVariant,
                async: false,
                success: function(cart){
                  newCartTotal = cart.total_price / 100;
                  Shopify.onCartUpdate(cart);
                  removeAtcProduct(newCartTotal);
                },
                error: function(){}
              });
            } else {
              newCartTotal = total_price / 100;
              removeAtcProduct(newCartTotal);
            }
          } else {
            newCartTotal = total_price / 100;
            removeAtcProduct(newCartTotal);
          }
        },
        error: function() {
          alert("Something went wrong. Please try again later!");
        }
      });
    }, 2000);
  });

  $(document).on("click", 'button[data-qty-change="inc"]', function() {
    $(".cart-loader").css("display", "block");
    $(".scd__footer .sf__btn.sf__btn-primary").addClass("disabled disabled-po");
    let variant_id = $(this).attr("data-variant_id");
    let variant_qty = $(this).closest(".scd-item__info").find(".scd-item__qty_input").val();

    setTimeout(function(){
      $.ajax({
        type: 'GET',
        url: '/cart.json',
        dataType: 'json',
        success: function(result) {
          let total_price = result.total_price;

          for (const i of result.items) {
            if(i.id == variant_id) {
              if(i.quantity == variant_qty) {
                const addVariant = {
                  id: variant_id,
                  quantity: Number(variant_qty) + 1
                };
                
                $.ajax({
                  type: 'POST',
                  url: '/cart/change.js',
                  dataType: 'json',
                  data: addVariant,
                  async: false,
                  success: function(cart){
                    newCartTotal = cart.total_price / 100;
                    Shopify.onCartUpdate(cart);
                    removeAtcProduct(newCartTotal);
                  },
                  error: function(){}
                });
              } else {
                newCartTotal = total_price / 100;
                removeAtcProduct(newCartTotal);
              }
              break;
            }
          }
        },
        error: function() {
          alert("Something went wrong. Please try again later!");
        }
      });
    }, 2000);
  });
}
// saloni-rachet-cart-drawer