/*
document.addEventListener('DOMContentLoaded', (event) => {
  var countdownContainer = document.querySelector('#countdown-container');

  var hours = parseInt(countdownContainer.getAttribute('data-hours'));
  var minutes = parseInt(countdownContainer.getAttribute('data-minutes'));
  var seconds = parseInt(countdownContainer.getAttribute('data-seconds'));

  // Determine a unique key based on the current URL pathname
  var uniqueKey = 'countdown' + window.location.pathname;

  var time_in_seconds = localStorage.getItem(uniqueKey) ? parseInt(localStorage.getItem(uniqueKey)) : hours * 3600 + minutes * 60 + seconds;

  function startTimer(duration, display) {
    var timer = duration, hours, minutes, seconds;
    var interval = setInterval(function () {
      hours = parseInt(timer / 3600, 10);
      minutes = parseInt((timer % 3600) / 60, 10);
      seconds = parseInt(timer % 60, 10);

      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      display.textContent = hours + "h " + minutes + "m " + seconds + "s";

      localStorage.setItem(uniqueKey, timer); // Using the unique key

      if (--timer < 0) {
        timer = duration;
        clearInterval(interval); // Clear the interval if time's up
      }
    }, 1000);
  }

  var display = document.querySelector('#countdown');
  startTimer(time_in_seconds, display);
});
*/



document.addEventListener('DOMContentLoaded', (event) => {
  var countdownContainer = document.querySelector('#countdown-container');

  // Extract the end date and time from the data attribute
  var endDateTime = countdownContainer.getAttribute('data-enddate');
  var endTime = new Date(endDateTime).getTime();

  function startTimer(display) {
    var interval = setInterval(function () {
      var now = new Date().getTime();
      var distance = endTime - now;

      // Time calculations
      var hours = Math.floor(distance / (1000 * 60 * 60));
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);

      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      display.textContent = hours + "h " + minutes + "m " + seconds + "s";

      if (distance < 0) {
        clearInterval(interval);
        display.textContent = "00h 00m 00s";
      }
    }, 1000);
  }

  var display = document.querySelector('#countdown');
  startTimer(display);
});
