/**
 * DEVELOPER DOCUMENTATION
 *
 * Include your custom JavaScript here.
 *
 * The theme Focal has been developed to be easily extensible through the usage of a lot of different JavaScript
 * events, as well as the usage of custom elements (https://developers.google.com/web/fundamentals/web-components/customelements)
 * to easily extend the theme and re-use the theme infrastructure for your own code.
 *
 * The technical documentation is summarized here.
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN A VARIANT HAS CHANGED
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever a the user has changed the variant in a selector. The target get you the form
 * that triggered this event.
 *
 * Example:
 *
 * document.addEventListener('variant:changed', function(event) {
 *   let variant = event.detail.variant; // Gives you access to the whole variant details
 *   let form = event.target;
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * MANUALLY CHANGE A VARIANT
 * ------------------------------------------------------------------------------------------------------------
 *
 * You may want to manually change the variant, and let the theme automatically adjust all the selectors. To do
 * that, you can get the DOM element of type "<product-variants>", and call the selectVariant method on it with
 * the variant ID.
 *
 * Example:
 *
 * const productVariantElement = document.querySelector('product-variants');
 * productVariantElement.selectVariant(12345);
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN A NEW VARIANT IS ADDED TO THE CART
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever a variant is added to the cart through a form selector (product page, quick
 * view...). This event DOES NOT include any change done through the cart on an existing variant. For that,
 * please refer to the "cart:updated" event.
 *
 * Example:
 *
 * document.addEventListener('variant:added', function(event) {
 *   var variant = event.detail.variant; // Get the variant that was added
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * BEING NOTIFIED WHEN THE CART CONTENT HAS CHANGED
 * ------------------------------------------------------------------------------------------------------------
 *
 * This event is fired whenever the cart content has changed (if the quantity of a variant has changed, if a variant
 * has been removed, if the note has changed...). This event will also be emitted when a new variant has been
 * added (so you will receive both "variant:added" and "cart:updated"). Contrary to the variant:added event,
 * this event will give you the complete details of the cart.
 *
 * Example:
 *
 * document.addEventListener('cart:updated', function(event) {
 *   var cart = event.detail.cart; // Get the updated content of the cart
 * });
 *
 * ------------------------------------------------------------------------------------------------------------
 * REFRESH THE CART/MINI-CART
 * ------------------------------------------------------------------------------------------------------------
 *
 * If you are adding variants to the cart and would like to instruct the theme to re-render the cart, you cart
 * send the cart:refresh event, as shown below:
 *
 * document.documentElement.dispatchEvent(new CustomEvent('cart:refresh', {
 *   bubbles: true
 * }));
 *
 * ------------------------------------------------------------------------------------------------------------
 * USAGE OF CUSTOM ELEMENTS
 * ------------------------------------------------------------------------------------------------------------
 *
 * Our theme makes extensive use of HTML custom elements. Custom elements are an awesome way to extend HTML
 * by creating new elements that carry their own JavaScript for adding new behavior. The theme uses a large
 * number of custom elements, but the two most useful are drawer and popover. Each of those components add
 * a "open" attribute that you can toggle on and off. For instance, let's say you would like to open the cart
 * drawer, whose id is "mini-cart", you simply need to retrieve it and set its "open" attribute to true (or
 * false to close it):
 *
 * document.getElementById('mini-cart').open = true;
 *
 * Thanks to the power of custom elements, the theme will take care automagically of trapping focus, maintaining
 * proper accessibility attributes...
 *
 * If you would like to create your own drawer, you can re-use the <drawer-content> content. Here is a simple
 * example:
 *
 * // Make sure you add "aria-controls", "aria-expanded" and "is" HTML attributes to your button:
 * <button type="button" is="toggle-button" aria-controls="id-of-drawer" aria-expanded="false">Open drawer</button>
 *
 * <drawer-content id="id-of-drawer">
 *   Your content
 * </drawer-content>
 *
 * The nice thing with custom elements is that you do not actually need to instantiate JavaScript yourself: this
 * is done automatically as soon as the element is inserted to the DOM.
 *
 * ------------------------------------------------------------------------------------------------------------
 * THEME DEPENDENCIES
 * ------------------------------------------------------------------------------------------------------------
 *
 * While the theme tries to keep outside dependencies as small as possible, the theme still uses third-party code
 * to power some of its features. Here is the list of all dependencies:
 *
 * "vendor.js":
 *
 * The vendor.js contains required dependencies. This file is loaded in parallel of the theme file.
 *
 * - custom-elements polyfill (used for built-in elements on Safari - v1.0.0): https://github.com/ungap/custom-elements
 * - web-animations-polyfill (used for polyfilling WebAnimations on Safari 12, this polyfill will be removed in 1 year - v2.3.2): https://github.com/web-animations/web-animations-js
 * - instant-page (v5.1.0): https://github.com/instantpage/instant.page
 * - tocca (v2.0.9); https://github.com/GianlucaGuarini/Tocca.js/
 * - seamless-scroll-polyfill (v2.0.0): https://github.com/magic-akari/seamless-scroll-polyfill
 *
 * "flickity.js": v2.2.0 (with the "fade" package). Flickity is only loaded on demand if there is a product image
 * carousel on the page. Otherwise it is not loaded.
 *
 * "photoswipe": v4.1.3. PhotoSwipe is only loaded on demand to power the zoom feature on product page. If the zoom
 * feature is disabled, then this script is never loaded.
 */

// saloni-open-first-menu-accordion
// $(document).on("click", '.header__icon-wrapper[aria-controls="mobile-menu-drawer"]', function() {
//   // $('.mobile-nav__item[data-level="1"]').find('button[aria-controls="mobile-menu-1"]').trigger("click");
//   $('.mobile-nav__item[data-level="1"]').find('button[aria-controls="mobile-menu-1"]').attr("aria-expanded", "true");
//   $('.mobile-nav__item[data-level="1"]').find('collapsible-content#mobile-menu-1').attr("open", "open");
//   $('.mobile-nav__item[data-level="1"]').find('collapsible-content#mobile-menu-1').css("overflow", "visible");
// });
// saloni-open-first-menu-accordion

// saloni-open-menu-by-footer-collection
$(document).on("click", ".footer__sticky-collection", function(e) {
  e.preventDefault();
  $(this).parents("body").find('.header__icon-wrapper[aria-controls="mobile-menu-drawer"]').click();
});
// saloni-open-menu-by-footer-collection

// saloni-product
$(".product-meta .jm-badge").click(function() {
  $('html,body').animate({
    scrollTop: $("#judgeme_product_reviews").offset().top - 150
  }, 'fast');
});

$(document).on("click", ".active-offers-container .copy_code", function() {
  var temp = $("<input>");
  $("body").append(temp);
  temp.val($(this).prev().text()).select();
  document.execCommand("copy");
  temp.remove();
  let displayMsg = $(this).find(".tooltiptext");
  displayMsg.css("visibility", "visible");
  setTimeout(function() {
    displayMsg.css("visibility", "hidden");
  }, 1000);
});

$(document).on("click", "#read_more_desc", function() {
  if(screen.width <= 740) {
    $("#product-desc-trust-popover").attr("open", "open");
  } else {
    $("#product-desc-trust-drawer").attr("open", "open");
  }
});

$(document).on("click", "#view_all_ingredients", function() {
  if(screen.width <= 740) {
    $("#product-ingredients-trust-popover").attr("open", "open");
  } else {
    $("#product-ingredients-trust-drawer").attr("open", "open");
  }
});

$(document).on("click", "#read_more_faqs", function() {
  if(screen.width <= 740) {
    $("#product-faqs-trust-popover").attr("open", "open");
  } else {
    $("#product-faqs-trust-drawer").attr("open", "open");
  }
});

$(".product-sticky-form__payment-container .custom_qty_btn").on("click", function() {
  setTimeout(function() {
    let qty = $(".custom_qty").val();
    $(".product-form").find(".quantity-selector__input").val(qty);
  }, 300);
});
// saloni-product

// saloni-tab-nav
const tabs_nav = document.querySelectorAll('.tab-nav-container .tabs-nav__item');

tabs_nav.forEach(tab_nav => {
  tab_nav.addEventListener('click', function(e) {
    e.preventDefault();
    let parentElm = tab_nav.closest(".tab-nav-container").classList;
    parentElm = String(parentElm).trim().replaceAll(" ", ".");
    let current_tabs_nav = document.querySelectorAll('.' + parentElm + ' .tabs-nav__item');
    current_tabs_nav.forEach(tabnav => {
      tabnav.classList.remove('active');
    });
    this.classList.add("active");
    
    const href = this.getAttribute("href");
    const offsetTop = document.querySelector(href).offsetTop - 150;
    scroll({
      top: offsetTop,
      behavior: "smooth"
    });
  });
});
// saloni-tab-nav

var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
      this.innerHTML = this.innerHTML.replace('&#9660;', '&#9650;');
    } else {
      panel.style.maxHeight = panel.scrollHeight + "10px";
      this.innerHTML = this.innerHTML.replace('&#9650;', '&#9660;');
    } 
  });
}

// saloni-play-and-win
$("#shopify-section--play-and-win .logo-list__item").on("click", function() {
  let gameLink = $(this).find(".logo-list__item-link").text();
  if(gameLink) {
    var iframe = '<iframe width="100%" height="75%" src="'+gameLink+'"></iframe>';
    $("#game-launcher-popup").append(iframe);
    $("#game-launcher-popup").addClass("visible");
    $("html").css("overflow-y", "hidden");
    $("main#MainContent").addClass("custom-modal-opacity");
  } else {
    $(".close-game-popup").trigger("click");
  }
});

$(".close-game-popup").on("click", function() {
  $("#game-launcher-popup").removeClass("visible");
  $("html").css("overflow-y", "unset");
  $("main#MainContent").removeClass("custom-modal-opacity");
  $("#game-launcher-popup iframe").remove();
});
// saloni-play-and-win

// saloni-surprise-for-you
$(".surprise__button").on("click", function(e) {
  e.preventDefault();
  $(this).parents(".surprise-for-you-popdraw").find("header button").trigger("click");
  $("#surprise-for-you-popup").addClass("visible");
  $("html").css("overflow-y", "hidden");
  $("main#MainContent").addClass("custom-modal-opacity");
});

$(".close-surprise-popup").on("click", function() {
  $("#surprise-for-you-popup").removeClass("visible");
  $("html").css("overflow-y", "unset");
  $("main#MainContent").removeClass("custom-modal-opacity");
});
// saloni-surprise-for-you

// saloni-newsletter-form
$(".newsletter-modal__form").on("submit", function(e) {
  const customerData = {tags: $('[name="contact[tags]"]').val(), email: $('[name="contact[email]"]').val(), phone: $('[name="contact[note][phone]"]').val()};

  $.ajax({
    type: 'POST',
    url: 'https://gift.discoverpilgrim.com/polls/update_newsletter_customer',
    data: JSON.stringify(customerData),
    dataType: "json",
    success: function (data) {
      alert("Newsletter subscribed!");
      console.log(data);
    },
    error: function (err) {
      alert('Something went wrong. Please try again later!');
    },
  });
});
// saloni-newsletter-form

// saloni-product-card-variant-swatch
$(document).on("click", ".swatch-wrapper", function() { //.product-item-meta__swatch-list.color-swatch-list
  $(this).parent().next(".product-item__cta-wrapper").find("button.product-item__cta").trigger("click");
});
// saloni-product-card-variant-swatch

// saloni-cart-drawer-reopen-minmaxify
$(document).on("click", ".minmaxify-ok", function() {
  $('.header__icon-wrapper[aria-controls="mini-cart"]').attr("aria-expanded", "true");
});
// saloni-cart-drawer-reopen-minmaxify

// saloni-corporate-gifting-scroll-to-callback-form
$(document).on("click", ".corporate_gifting_kits .gallery__figure img", function() {
  let scrollToSection = $(this).parents("#main").find("section.corporate_gifting_callback_form");
  $('html,body').animate({
    scrollTop: scrollToSection.offset().top - 100
  }, 'fast');
});
// saloni-corporate-gifting-scroll-to-callback-form

// saloni-cart-drawer-open-quickview-drawer
$(document).on("click", "quick-buy-drawer .quick_view_drawer_form .product-form__add-button", function() {
  $("quick-buy-drawer").find(".drawer__close-button").trigger("click");
  $('.header__icon-wrapper[aria-controls="mini-cart"]').attr("aria-expanded", "true");
});
// saloni-cart-drawer-open-quickview-drawer

// saloni-change-variant-price-on quick-buy
$(document).on("click", ".quick-buy-popover-content .color-swatch__radio, .quick-buy-drawer-content .color-swatch__radio", function() {
  let variantPrice = $(this).attr("variant-price");
  let variantComparePrice = $(this).attr("variant-compare-price");
  $(".quick-buy-popover-content .price-list").find("span.price.price--highlight").text(variantPrice);
  $(".quick-buy-drawer-content .price-list").find("span.price.price--highlight").text(variantPrice);
  
  if(variantComparePrice) {
    $(".quick-buy-popover-content .price-list").find("span.price.price--compare").text(variantComparePrice).show();
    $(".quick-buy-drawer-content .price-list").find("span.price.price--compare").text(variantComparePrice).show();
    variantPrice = variantPrice.replace("₹", "").replace(",", "").split(".");
    variantComparePrice = variantComparePrice.replace("₹", "").replace(",", "").split(".");
    variantPrice = Number(variantPrice[0]);
    variantComparePrice = Number(variantComparePrice[0]);
    let variantDiscountPercent = ((variantComparePrice - variantPrice) * 100) / variantComparePrice;
    variantDiscountPercent = Math.round(variantDiscountPercent);
    $(".quick-buy-popover-content .price-list").find("span.discount-percentage").text("("+variantDiscountPercent+"% OFF)").show();
    $(".quick-buy-drawer-content .price-list").find("span.discount-percentage").text("("+variantDiscountPercent+"% OFF)").show();
  } else {
    $(".quick-buy-popover-content .price-list").find("span.price.price--compare").hide();
    $(".quick-buy-drawer-content .price-list").find("span.price.price--compare").hide();
    $(".quick-buy-popover-content .price-list").find("span.discount-percentage").hide();
    $(".quick-buy-drawer-content .price-list").find("span.discount-percentage").hide();
  }
});
// saloni-change-variant-price-on quick-buy

// saloni-on-change-skintone-filter
$(document).on("click", ".skintone-tab-nav .tabs-nav__item", function() {
  let skintone = $(this).attr("skintone");
  let currentVar = "{{ current_variant.title }}";
  let altText = currentVar + "_" + skintone;

  $(".skintone_images").each(function() {
    $(this).css("display", "none");
  });

  if($(".skintone_image_wrapper").find("#"+skintone).length == 0) {
    $(".skintone_image_wrapper").find("#None").css("display", "block");
  } else {
    $("#"+skintone).css("display", "block");
  }
});
// saloni-on-change-skintone-filter

// saloni-change-variant-on-product-page
$(document).on("change", ".color-swatch__radio", function() {
  $(".product-form__variants").find('.color-swatch__radio[value="'+$(this).val()+'"]').trigger("click");
  setTimeout(function() {
    let checkedElement = $("input.color-swatch__radio:checked");
    let light_skintone_image = checkedElement.prev().attr("light_skintone_image");
    let medium_skintone_image = checkedElement.prev().attr("medium_skintone_image");
    let deep_skintone_image = checkedElement.prev().attr("deep_skintone_image");
    let no_skintone_image = checkedElement.prev().attr("no_skintone_image");
    let variant_subtitle = checkedElement.prev().attr("variant_subtitle");

    $(".variant-subtitle").text(variant_subtitle);
    
    if(light_skintone_image && medium_skintone_image && deep_skintone_image) {
      $(".skintone_images.light_skintone_image img").attr("src", light_skintone_image);
      $(".skintone_images.medium_skintone_image img").attr("src", medium_skintone_image);
      $(".skintone_images.deep_skintone_image img").attr("src", deep_skintone_image);
    } else if(no_skintone_image) {
      $(".skintone_images.no_skintone_image img").attr("src", no_skintone_image);
    }
  }, 50);
});
// saloni-change-variant-on-product-page

// saloni-change-quantity-on-product-page
$(".product-form .custom_qty_btn").on("click", function() {
  let thisEle = $(this).parent(".quantity-selector").find(".quantity-selector__input.custom_qty");
  setTimeout(function() {
    $(".product-form").find(".quantity-selector__input").val(thisEle.val());
    $(".product-sticky-form__payment-container").find(".quantity-selector__input").val(thisEle.val());
  }, 300);
});
// saloni-change-quantity-on-product-page

// saloni-open-newsletter-popup-on-banner-click
$(document).on("click", ".banner_newsletter", function() {
  $('button[aria-controls="newsletter-popup"]').trigger("click");
});
// saloni-open-newsletter-popup-on-banner-click