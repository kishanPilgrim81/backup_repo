// saloni-login
// to remove number from session on refresh
$(document).ready(function() {
  sessionStorage.removeItem("loginVerified_num");
});

// focus mobile number field each time truecaller fail
function loginTruecallerFallback() {
  setTimeout(function() {
    $("#loginMobileForm").find("input#mobileNumber").focus();
  });
}

function loginTruecaller() {
  if($(window).width() < 1000 && !(/^((?!chrome|android).)*safari/i.test(navigator.userAgent))) {
    function makeid(length) {
      let result = '';
      const randChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      const randCharsLength = randChars.length;
      let reqCounter = 0;
      while (reqCounter < length) {
        result += randChars.charAt(Math.floor(Math.random() * randCharsLength));
        reqCounter += 1;
      }
      return result;
    }
    
    const UNIQUE_REQUEST_ID = makeid(10);
    const YOUR_APP_KEY = "LHnB186d9a54bd75e4e61a65e36744dc9a4ca";
    const YOUR_APP_NAME = "Pilgrim truecalller";
    window.location = "truecallersdk://truesdk/web_verify?type=btmsheet&requestNonce=" + UNIQUE_REQUEST_ID + "&partnerKey=" + YOUR_APP_KEY + "&partnerName=" + YOUR_APP_NAME + "&lang=en&loginPrefix=checkout&loginSuffix=loginsignup&ctaPrefix=proceedwith&ctaColor=%23faca0c&ctaTextColor=%23000000&btnShape=round&skipOption=manualdetails&ttl=20000";
  
    setTimeout(function() {
      if(document.hasFocus()) {
        // Truecaller app not present on the device and you redirect the user 
        // to your alternate verification page
        loginTruecallerFallback();
      } else {
        // Truecaller app present on the device and the profile overlay opens
        // The user clicks on verify & you'll receive the user's access token to fetch the profile on your 
        // callback URL - post which, you can refresh the session at your frontend and complete the user verification
        let tc_response = setInterval(function() {
          $.ajax({
            type: "GET",
            url: "https://webengagebackup.discoverpilgrim.com/polls/fetch_tc_customer?requestId="+UNIQUE_REQUEST_ID,
            dataType: "json",
            contentType: "application/json",
            success: function(result) {
              if(result['status'] == 200) {
                clearInterval(tc_response);
                // updateCartAttr("truecallerlogin");
                $(".login-tc-wrapper").removeClass("hidden");
                $(".login-tc-loader").attr("open", "open");
                if(result['data']['phoneNumbers'][0]) {
                  let phoneNumber = Number(result['data']['phoneNumbers'][0].toString().slice(-10));
                  if(!isBraveBrowser) {
                    const eventData = {
                      "entry_point": $("#login-modal").attr("entry_point"),
                      "mobile_number": phoneNumber,
                      "resend_otp": "False",
                      "method": "truecaller"
                    };
                    Moengage.track_event("otp_requested", eventData);
  
                    const eventData1 = {
                      "entry_point": $("#login-modal").attr("entry_point"),
                      "mobile_number": phoneNumber,
                      "method": "truecaller"
                    };
                    Moengage.track_event("otp_verified", eventData1);
                  }
                  
                  $.ajax({
                    type: "POST",
                    url: "https://webengagebackup.discoverpilgrim.com/polls/generate-multipass-url/",
                    data: JSON.stringify({ mobile_number: phoneNumber }),
                    contentType: "application/json",
                    dataType: "json",
                    success: function(response) {
                      $(".login-tc-wrapper").addClass("hidden");
                      $(".login-tc-loader").removeAttr("open");
                      $(".login-loader").removeClass("hidden");
                      $(".login-content").addClass("hidden");
                      localStorage.setItem("loginredirect", window.location.href);
                      if(!isBraveBrowser) {
                        const eventData2 = {
                          "entry_point": $("#login-modal").attr("entry_point"),
                          "mobile_number": phoneNumber,
                          "method": "truecaller"
                        };
                        Moengage.track_event("login_success", eventData2);
                      }
                      
                      window.location.href = response.login_url;
                    },
                    statusCode: {
                      404: function(request, status, error) {
                        $(".login-tc-wrapper").addClass("hidden");
                        $(".login-tc-loader").removeAttr("open");
                        let userEmail = result['data']['onlineIdentities']['email'];
                        let userName = result['data']['name']['first'] + " " + result['data']['name']['last'];
                        $("#loginMobileForm").addClass("hidden");
                        $("#loginOtpForm").addClass("hidden");
                        $("#loginAddressForm").removeClass("hidden");
                        $("#loginAddressForm #loginTags").val("accountlogin_truecaller");
                        $("#loginAddressForm").attr("truecaller", "true");
                        $("#loginAddressForm #loginFullName").focus();
                        if(userName) {
                          $("#loginAddressForm #loginFullName").val(userName);
                          $("#loginAddressForm #loginFullName").trigger("input");
                          $("#loginAddressForm #loginFullName").parent(".field-wrapper").addClass("hasValue");
                        }
                        sessionStorage.setItem('loginVerified_num', phoneNumber);
                        $("#loginAddressForm #email").val(userEmail);
                        $("#loginAddressForm #email").parent(".field-wrapper").addClass("hasValue");
                        $("#loginMobileForm #mobileNumber").val(phoneNumber);
                        $("#loginMobileForm #mobileNumber").parent(".field-wrapper").addClass("hasValue");
                      }
                    },
                    error: function (jqXHR, exception) {
                      if(jqXHR.status != 404) {
                        alert("Something went wrong. Please refresh the page & try again!");
                      }
                    },
                  });
                }
              } else if(result['status'] == 202) {
                clearInterval(tc_response);
                loginTruecallerFallback();
              }
            },
            error: function() {
              alert("Something went wrong. Please refresh the page & try again!");
            }
          });
        }, 500);
  
        setTimeout(function() {
          clearInterval(tc_response);
        }, 20000);
      }
    }, 600);
  } else {
    loginTruecallerFallback();
  }
}

// close popup on click back button
$(document).on("click", "#close-login", function() {
  const pageUrl = window.location.pathname;
  if(pageUrl == "/account/register") {
    window.location.href = "/";
  }
  $("#login-modal").css("display", "none");
  $("body").css("overflow", "unset");
});

// close popup on clicking anywhere for desktop screen
$(document).on("click", function(event) {
  if ($(event.target).closest("#login-modal").is(":visible")) {
    let target = $(event.target);
    if (target.is("#login-modal")) {
      $("#login-modal").css("display", "none");
      $("body").css("overflow", "unset");
    }
  }
});

// set focus on the field
$(document).on("click", "#login-modal .field-wrapper", function() {
  $(this).closest(".field-wrapper").find("input").focus();
});

// add/remove class to display placeholder accordingly
$(document).on("keyup change", "#login-modal .field-wrapper input", function() {
  var value = $.trim($(this).val());
  if (value) {
    $(this).closest(".field-wrapper").addClass("hasValue");
  } else {
    $(this).closest(".field-wrapper").removeClass("hasValue");
  }
});

// {% comment %}
// ------------------------------------------------------------------------------------------------
//   STEP 1:: Mobile
// ------------------------------------------------------------------------------------------------
// {% endcomment %}

// on click or focus, shift button to center
document.querySelector('#loginMobileForm #mobileNumber').addEventListener('click', () => {
  setTimeout(() => {
    document.querySelector('#loginMobileForm #mobileNumber').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 300);
});
``
document.querySelector('#loginMobileForm #mobileNumber').addEventListener('focus', () => {
  setTimeout(() => {
    document.querySelector('#loginMobileForm #mobileNumber').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 500);
});

// on change phone field
$(document).on("input change", "#loginMobileForm #mobileNumber", function(e) {
  $("#mobileNumberError").addClass("hidden");
  $("#loginSendOtpBtn").removeAttr("disabled");
});

// on keypress phone field, check format, allow numbers only and add space
$(document).on("keypress input", "#loginMobileForm #mobileNumber", function(e) {
  let phoneNum = $(this).val();
  let phoneNum1, newPhoneNum, newPhoneNum1;
  
  if(phoneNum.charAt(0) == "+" && phoneNum.charAt(1) == "9" && phoneNum.charAt(2) == "1") {
    newPhoneNum = phoneNum.substring(3, phoneNum.length);
  } else {
    newPhoneNum = phoneNum;
  }
  if((newPhoneNum+'').match(/^[0-4]/)) {
    newPhoneNum1 = (newPhoneNum+'').replace(/^[0-4]+/g, '');
  } else {
    newPhoneNum1 = newPhoneNum;
  }
  let charCode = (e.which) ? e.which : event.keyCode;
  if (String.fromCharCode(charCode).match(/\D/g)) {
    e.preventDefault();
    phoneNum1 = newPhoneNum1.replace(/\D/g, '');
    $(this).val(phoneNum1);
    return false;
  }
  let newPhone = newPhoneNum1.replace(/ /g, "").trim(); // .replace(/^(\d{5})(\d*)$/, "$1 $2")

  $(this).val(newPhone);
  $(this).parent(".field-wrapper").addClass("hasValue");
});

// on paste phone, check format
$(document).bind("paste", "#loginMobileForm #mobileNumber", function(e) {
  let phoneNum = e.originalEvent.clipboardData.getData('text');
  let newPhoneNum, newPhoneNum1;
  
  if ((phoneNum+'').match(/[^0-9+\s]/g)) {
    return false;
  }
  if(phoneNum.charAt(0) == "+" && phoneNum.charAt(1) == "9" && phoneNum.charAt(2) == "1") {
    newPhoneNum = phoneNum.substring(3, phoneNum.length).trim();
  } else {
    newPhoneNum = phoneNum;
  }
  if((newPhoneNum+'').match(/^[0-4]/)) {
    newPhoneNum1 = (newPhoneNum+'').replace(/^[0-4]+/g, '').trim();
  } else {
    newPhoneNum1 = newPhoneNum;
  }
  let newPhone = newPhoneNum1.replace(/ /g, "").substring(10); // .replace(/^(\d{5})(\d*)$/, "$1 $2")

  $(this).val(newPhone);
  $(this).focus();
  $(this).parent(".field-wrapper").addClass("hasValue");
});

// on clicking continue button, send OTP
$(document).on("click", "#loginSendOtpBtn", function() {
  $("#sendOtpBtn").attr("disabled", "disabled");
  const mobileNumber = $('#loginMobileForm #mobileNumber').val().replace(" ", "").replace(/^[0-4]+/g, '');
  
  if(mobileNumber) {
    if(mobileNumber.length != 10) {
      $("#mobileNumberError").removeClass("hidden");
      $("#mobileNumberError").text("Please enter a 10 digit phone number");
    } else {
      $("#mobileNumberError").addClass("hidden");
      let mobile = sessionStorage.getItem('loginVerified_num');
      $("#mobileNumberDisplay").text(" +91 " + mobileNumber);

      if(mobile && mobile == mobileNumber) {
        $("#loginMobileForm").addClass("hidden");
        $("#loginAddressForm").removeClass("hidden");
        $("#loginAddressForm #fullName").focus();
        sessionStorage.setItem('loginVerified_num', mobileNumber);
      } else {
        $("#loginOtpForm").find('input.verify_loginOtp').val("");
        sendOtp(mobileNumber);
      }
    }
  } else {
    $("#mobileNumberError").removeClass("hidden");
    $("#mobileNumberError").text("Please enter a valid phone number");
  }
});

// Function to get the customer name based on the mobile number
function getCustomerName(mobileNumber) {
  const apiUrl = `https://webengagebackup.discoverpilgrim.com/polls/get_customer_name/?mobile_number=${mobileNumber}`;
  $.ajax({
    type: "GET",
    url: apiUrl,
    dataType: 'json',
    success: function(response) {
      const customerName = response.customer_name;
      $("#loginOtpForm h4").text(`Welcome ${customerName}!`);
    },
    error: function(jqXHR) {
      if(jqXHR.status == 404) {
        $("#loginOtpForm h4").text(`Welcome!`);
      } else {
        $("#loginOtpForm h4").text(`Welcome back!`);
      }
    }
  });
}

// function to send OTP
function sendOtp(mobileNumber) {
  if(mobileNumber) {
    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/otp_sender/",
      data: JSON.stringify({ mobile_number: mobileNumber }),
      contentType: "application/json",
      dataType: "json",
      success: function(response) {
        if(!isBraveBrowser) {
          const eventData = {
            "entry_point": $("#login-modal").attr("entry_point"),
            "mobile_number": mobileNumber,
            "resend_otp": "False",
            "method": "manual"
          };
          Moengage.track_event("otp_requested", eventData);
        }
        
        getCustomerName(mobileNumber);
        $("#loginMobileForm").addClass("hidden");
        $("#loginOtpForm").removeClass("hidden");
        $("#loginOtpForm").find('input.verify_loginOtp:first').focus();
        let loginTimeLeft = 30;
        let loginTimerId = setInterval(function() {
          if (loginTimeLeft == -1) {
            clearTimeout(loginTimerId);
            $(".login-resend-otp-text").hide();
            $("#loginResendOtpBtn").removeClass("disabled");
          } else {
            $("#login-resend-otp-timer").text("0:" + String(loginTimeLeft).padStart(2, '0'));
            loginTimeLeft--;
          }
        }, 1000);
      },
      statusCode: {
        400: function(request, status, error) {
          $("#mobileNumberError").removeClass("hidden");
          $("#mobileNumberError").text(request.responseJSON.error);
          $("#loginSendOtpBtn").removeAttr("disabled");
        },
        401: function(request, status, error) {
          $("#mobileNumberError").removeClass("hidden");
          $("#mobileNumberError").text(request.responseJSON.error);
          $("#loginSendOtpBtn").removeAttr("disabled");
        },
        403: function(request, status, error) {
          $("#mobileNumberError").removeClass("hidden");
          $("#mobileNumberError").text("Sending OTP not allowed for your device/location.");
        },
        429: function(request, status, error) {
          $("#mobileNumberError").removeClass("hidden");
          $("#mobileNumberError").text("OTP request limit exceeded for today.");
        }
      },
      error: function (jqXHR, exception) {
        if(jqXHR.status != 400 && jqXHR.status != 401 && jqXHR.status != 403 && jqXHR.status != 429) {
          $("#mobileNumberError").removeClass("hidden");
          $("#mobileNumberError").text("Error sending OTP. Please try again.");
          $("#loginSendOtpBtn").removeAttr("disabled");
        }
      }
    });
  }
}

// {% comment %}
// ------------------------------------------------------------------------------------------------
//   STEP 2:: OTP
// ------------------------------------------------------------------------------------------------
// {% endcomment %}

// on keypress type tel fields, allow numbers only
$(document).on("keypress input", '#login-modal .verify_loginOtp', function(e) {
  let inputVal = $(this).val();
  let charCode = (e.which) ? e.which : event.keyCode;
  if (String.fromCharCode(charCode).match(/\D/g)) {
    e.preventDefault();
    inputVal = inputVal.replace(/\D/g, '');
    $(this).val(inputVal);
    return false;
  }
});

// on input otp, hide error
$(document).on("input change", "#loginOtpForm .verify_loginOtp", function() {
  $("#loginOtp-error").addClass("hidden");
  $("#loginVerifyButton").removeAttr("disabled");
});

// on input otp, hide error and shift focus to next input field
$(document).on("input", "#loginOtpForm .verify_loginOtp", function() {
  let otpCode = Array.from($('#loginOtpForm .verify_loginOtp')).map(input => $(input).val()).join('').trim();
  let otpArray = otpCode.split('');
  $('#loginOtpForm .verify_loginOtp').val("");
  $("#loginOtpForm .verify_loginOtp").each(function (index, element) {
    $(this).val(otpArray[index]);
    if ($(this).val().length == 1) {
      $(this).parent().next().find('input.verify_loginOtp').focus();
    }
  });

  if(otpCode.length == 4) {
    // Call your OTP verification function here
    $("#loginVerifyButton").trigger("click");
  }
});

// on keyup, shift focus to next input field
$(document).on("keyup", "#loginOtpForm .verify_loginOtp", function() {
  if ($(this).val().length == 1) {
    $(this).parent().next().find('input.verify_loginOtp').focus();
  }
});

// on keypress, check length of the input
$(document).on("keypress", "#loginOtpForm .verify_loginOtp", function() {
  if ($(this).val().length == 1) {
    return false;
  }
});

// on keydown, control backspace functionality
$(document).on("keydown", "#loginOtpForm .verify_loginOtp", function(e) {
  if (e.which == 8 && $(this).val().length == 0) {
    $(this).parent().prev().find('.verify_loginOtp').focus();
  }
});

// on clicking edit phone button
$(document).on("click", "#editloginMobileBtn", function() {
  $("#loginOtpForm").addClass("hidden");
  $("#loginAddressForm").addClass("hidden");
  $("#loginMobileForm").removeClass("hidden");
  $("#loginMobileForm").find("input#mobileNumber").focus();
  $("#loginSendOtpBtn").removeAttr("disabled");
});

// on clicking resend OTP button
$(document).on("click", "#loginResendOtpBtn", function() {
  $("#loginOtp-error").addClass("hidden");
  if (!$(this).hasClass('disabled')) {
    const mobileNumber = $('#loginMobileForm #mobileNumber').val().replace(" ", "");
    $(".login-resend-otp-text").show();
    $("#loginResendOtpBtn").addClass("disabled");

    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/otp_sender/",
      data: JSON.stringify({ mobile_number: mobileNumber }),
      contentType: "application/json",
      dataType: "json",
      success: function() {
        if(!isBraveBrowser) {
          const eventData = {
            "entry_point": $("#login-modal").attr("entry_point"),
            "mobile_number": mobileNumber,
            "resend_otp": "True",
            "method": "manual"
          };
          Moengage.track_event("otp_requested", eventData);
        }
        
        $("#loginOtpForm").find('input.verify_loginOtp').val("");
        $("#loginOtpForm").find('input.verify_loginOtp:first').focus();
        let loginTimeLeft = 30;
        let loginTimerId = setInterval(function() {
          if (loginTimeLeft == -1) {
            clearTimeout(loginTimerId);
            $(".login-resend-otp-text").hide();
            $("#loginResendOtpBtn").removeClass("disabled");
          } else {
            $("#login-resend-otp-timer").text("0:" + String(loginTimeLeft).padStart(2, '0'));
            loginTimeLeft--;
          }
        }, 1000);
      },
      statusCode: {
        400: function(request, status, error) {
          $("#loginOtp-error").removeClass("hidden");
          $("#loginOtp-error").text(request.responseJSON.error);
        },
        401: function(request, status, error) {
          $("#loginOtp-error").removeClass("hidden");
          $("#loginOtp-error").text(request.responseJSON.error);
        },
        403: function(request, status, error) {
          $("#loginOtp-error").removeClass("hidden");
          $("#loginOtp-error").text("Sending OTP not allowed for your device/location.");
        },
        429: function(request, status, error) {
          $("#loginOtp-error").removeClass("hidden");
          $("#loginOtp-error").text("OTP request limit exceeded for today.");
        }
      },
      error: function(jqXHR) {
        if(jqXHR.status != 400 && jqXHR.status != 401 && jqXHR.status != 429) {
          $("#loginOtp-error").removeClass("hidden");
          $("#loginOtp-error").text("Error sending OTP. Please try again.");
        }
      }
    });
  }
  return false;
});

// auto read OTP
if ('OTPCredential' in window) {
  window.addEventListener('DOMContentLoaded', e => {  
    const abrtCtrl = new AbortController();
    navigator.credentials.get({
      otp: { transport:['sms'] },
      signal: abrtCtrl.signal
    }).then(otp => {
      // Check which OTP container is in viewport
      if($("#login-modal").css('display') == 'block') {
        // Targeting OTP inputs within the mobile-otp-container
        const loginOtpInput = document.querySelectorAll("#loginOtpForm .verify_loginOtp");
    
        if (loginOtpInput.length === 0) return;
        
        if (otp.code.length !== loginOtpInput.length) {
          $("#loginOtp-error").removeClass("hidden");
          $("#loginOtp-error").text("OTP length does not match the number of input fields.");
          return;
        }
    
        const otpArray = otp.code.split('');
        loginOtpInput.forEach((input, index) => {
          input.value = otpArray[index];
        });
    
        // Call your OTP verification function here
        $("#loginVerifyButton").trigger("click");
        abrtCtrl.abort();
      }
      if($("#prelogin-modal").css('display') == 'block') {
        // Targeting OTP inputs within the mobile-otp-container
        const otpInput = document.querySelectorAll("#otpForm .verify_otp");
    
        if (otpInput.length === 0) return;
        
        if (otp.code.length !== otpInput.length) {
          $("#otp-error").removeClass("hidden");
          $("#otp-error").text("OTP length does not match the number of input fields.");
          return;
        }
    
        const otpArray = otp.code.split('');
        otpInput.forEach((input, index) => {
          input.value = otpArray[index];
        });
    
        // Call your OTP verification function here
        $("#verifyOtpBtn").trigger("click");
        abrtCtrl.abort();
      }
    }).catch(err => {
      abrtCtrl.abort();
      // alert("Error in OTP retrieval " + err);
      // $(otpErrorSelector).removeClass("hidden");
      // $(otpErrorSelector).text("Error in OTP retrieval " + err);
    });
  });
}

// on clicking continue button, check format and verify OTP
$(document).on("click", "#loginVerifyButton", function() {
  $("#loginVerifyButton").attr("disabled", "disabled");
  $("#loginOtp-error").addClass("hidden");
  const otp = Array.from($('.verify_loginOtp')).map(input => $(input).val()).join('');
  const mobileNumber = $('#loginMobileForm #mobileNumber').val().replace(" ", "");
  
  if(otp.length == 4) {
    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/verify_otp/",
      data: JSON.stringify({ mobile_number: mobileNumber, otp: otp }),
      contentType: "application/json",
      dataType: "json",
      success: function(response) {
        if(!isBraveBrowser) {
          const eventData = {
            "entry_point": $("#login-modal").attr("entry_point"),
            "mobile_number": mobileNumber,
            "method": "manual"
          };
          Moengage.track_event("otp_verified", eventData);
        }
        
        $("#loginOtp-error").addClass("hidden");
        if (response.message.includes("Please signup")) {
          $("#loginOtpForm").addClass("hidden");
          $("#loginAddressForm").removeClass("hidden");
          $("#loginAddressForm #loginTags").val("accountlogin_manual");
          $("#loginAddressForm #fullName").focus();
          sessionStorage.setItem('loginVerified_num', mobileNumber);
        } else {
          $("#login-loader").removeClass("hidden");
          $("#login-content").addClass("hidden");
          localStorage.setItem("loginredirect", window.location.href);
          if(!isBraveBrowser) {
            const eventData = {
              "entry_point": $("#login-modal").attr("entry_point"),
              "mobile_number": mobileNumber,
              "method": "manual"
            };
            Moengage.track_event("login_success", eventData);
          }
          
          window.location.href = response.login_url;
        }
      },
      error: function() {
        $("#loginOtp-error").removeClass("hidden");
        $("#loginOtp-error").text("Invalid OTP. Please try again.");
      }
    });
  } else {
    $("#loginOtp-error").removeClass("hidden");
    $("#loginOtp-error").text("Please enter a valid OTP.");
  }
});

// {% comment %}
// ------------------------------------------------------------------------------------------------
//   STEP 3:: Sign up
// ------------------------------------------------------------------------------------------------
// {% endcomment %}

// on change address form fields, hide the respective field error
$(document).on("input change", "#loginAddressForm input", function() {
  $(this).parents(".field-wrapper").next("p.input-error").addClass("hidden");
  $("#registerinputerrorsverify").addClass("hidden");
});

$(document).on("change", ".gender-radio", function() {
  // Remove active class from all labels
  $('.gender-label').each(function() {
    $(this).removeClass("selectedGender");
  });

  // Add active class to the selected label
  $(this).next().addClass("selectedGender");
});

// function to generate password
function generatePassword(length) {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let password = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }
  return password;
}

// function to check all address form validations
function checkLoginValidation() {
  let error = false;
  const emailRegex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  if(!$("#loginAddressForm #loginFullName").val()) {
    error = true;
    $("#loginFullName-error").removeClass("hidden");
    $("#loginFullName-error").text("Please enter a valid name.");
  } else {
    $("#loginFullName-error").addClass("hidden");
  }
  if(!$("#loginAddressForm #loginEmail").val()) {
    error = true;
    $("#loginEmail-error").removeClass("hidden");
    $("#loginEmail-error").text("Please enter a valid email.");
  } else if (!emailRegex.test($("#loginAddressForm #loginEmail").val())) {
    error = true;
    $("#loginEmail-error").removeClass("hidden");
    $("#loginEmail-error").text("Email is not valid.");
  } else {
    $("#loginEmail-error").addClass("hidden");
  }
  return error;
}

// on clicking continue button, register user
$(document).on("click", "#registerUserBtn", function() {
  let loginValidationErr = checkLoginValidation();
  if(!loginValidationErr || loginValidationErr == "false") {
    let fullName = $("#loginAddressForm #loginFullName").val().trim();
    let fname, lname;
    if(fullName.indexOf(" ") !== -1) {
      let splitName = fullName.split(" ");
      lname = splitName.pop();
      fname = splitName.join(" ");
      if(lname == "") {
        lname = ",";
      }
    } else {
      lname = ",";
      fname = fullName;
    }
    let password = generatePassword(8);
    let email = $("#loginAddressForm #loginEmail").val();
    let gender = $('#loginAddressForm input[name="gender"]:checked').val();
    let mobileNumber = $("#loginMobileForm #mobileNumber").val();
  
    const data = {
      "first_name": fname,
      "last_name": lname,
      "mobile_number": mobileNumber,
      "password": password,
      "email": email,
      "autopopup": "no",
      "gender": gender,
      "tags": $("#loginAddressForm #loginTags").val()
    };
  
    $.ajax({
      type: "POST",
      url: "https://webengagebackup.discoverpilgrim.com/polls/register/",
      data: JSON.stringify(data),
      contentType: "application/json",
      dataType: "json",
      success: function(response) {
        // Redirect to the login URL
        $("#login-loader").removeClass("hidden");
        $("#login-content").addClass("hidden");
        localStorage.setItem('signupfired', 'true');
        localStorage.setItem("loginredirect", window.location.href);
        let loginMethod = "manual";
        let isTruecaller = $("#loginAddressForm").attr("truecaller");
        if(isTruecaller == "true") {
          loginMethod = "truecaller";
        }
        if(!isBraveBrowser) {
          const eventData = {
            "entry_point": $("#login-modal").attr("entry_point"),
            "mobile_number": mobileNumber,
            "method": loginMethod,
            "first_name": fname,
            "last_name": lname,
            "email": email,
            "gender": gender
          };
          Moengage.track_event("signup_success", eventData);
        }
        
        setTimeout(function() {
          window.location.href = response.login_url;
        }, 50);
      },
      error: function(result) {
        let registerErr = false;
        if(result.responseJSON.error) {
          registerErr = true;
          $("#loginEmail-error").removeClass("hidden");
          $("#loginEmail-error").text(result.responseJSON.error);
        } else if(result.responseJSON.email) {
          registerErr = true;
          $("#loginEmail-error").removeClass("hidden");
          $("#loginEmail-error").text(result.responseJSON.email);
        }
        if(result.responseJSON.first_name) {
          registerErr = true;
          $("#loginFullName-error").removeClass("hidden");
          $("#loginFullName-error").text(result.responseJSON.first_name);
        } else if(result.responseJSON.last_name) {
          registerErr = true;
          $("#loginFullName-error").removeClass("hidden");
          $("#loginFullName-error").text(result.responseJSON.last_name);
        }
        if(!registerErr) {
          $("#registerinputerrorsverify").removeClass("hidden");
          $("#registerinputerrorsverify").html("Something went wrong. Please try again later!");
        }
      }
    });
  }
});
// saloni-login