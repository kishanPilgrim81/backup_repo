document.addEventListener('DOMContentLoaded', (event) => {
  var countdownContainer = document.querySelector('#countdown-container');

  // Extract the end date and time from the data attribute
  var endDateTime = countdownContainer.getAttribute('data-enddate');
  var endTime = new Date(endDateTime).getTime();

  function startTimer(display) {
    var interval = setInterval(function () {
      var now = new Date().getTime();
      var distance = endTime - now;

      // Time calculations
      var hours = Math.floor(distance / (1000 * 60 * 60));
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);

      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      display.textContent = hours + "h " + minutes + "m " + seconds + "s";

      if (distance < 0) {
        clearInterval(interval);
        display.textContent = "00h 00m 00s";
      }
    }, 1000);
  }

  var display = document.querySelector('#countdown');
  startTimer(display);
});
