<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
  crossorigin="anonymous"></script>

<script>
  let sendOtpUrl = "https://clone.discoverpilgrim.com/api/sendotpforloginandsignup",
    verifyOtpUrl = "https://clone.discoverpilgrim.com/api/verifyotpforloginandsignup",
    otpVerified = false,
    timerCalled = { 'CustomerLoginForm': 0, 'CustomerRegisterForm': 0 },
    myTimeout = { 'CustomerLoginForm': 0, 'CustomerRegisterForm': 0 },
    parentID = "",
    inputNum = "",
    inputOtp = "",
    inputFname = "",
    inputLname = "",
    inputEmail = "",
    inputPass = "",
    data = "",
    not_both = false;

  //disable enter key
  $(document).keypress(
    function (event) {
      if (event.which == '13') {
        event.preventDefault();
      }
    });

  function hideAndShow(parentID, reverse = false, target = false) {
    if (reverse) {
      if (parentID == "CustomerRegisterForm") {
        $(`#${parentID} .boxx`).hide();
        $(`#${parentID} #otp_get`).show();
        $(`#${parentID} .form-list`).show();
        $(`#${parentID} #otp_msg`).empty();
      }
      else {
        $('.to_hide_login').show();
        $(`#${parentID} .boxx`).hide();
      }
      return;
    }

    if (parentID == "CustomerRegisterForm") {
      $(`#${parentID} .boxx`).show();
      $(`#${parentID} #digit-1`).focus();
      $(target).hide();
      $(`#${parentID} .form-list`).hide();
    }
    else {
      $('.to_hide_login').hide();
      $(`#${parentID} .boxx`).show();
      $(`#${parentID} #digit-1`).focus();
    }
  };

  $(document).on("click", "p.c_e_num", function (e) {
    var parentID = $(e.target).closest('[data-parent]').attr('id');
    hideAndShow(parentID, true);
    if (timerCalled[parentID] >= 1) {
      timerCalled[parentID] = 1;
      clearTimeout(myTimeout[parentID]);
      $(`#${parentID} .resend-otp`).show();
      $(`#${parentID} .resend-btn`).hide();
    }
  })

  //   Login input change depending on the input value

  $(document).on("input", ".phone_or_email:not(.after_login_fail_otp)", function (e) {
    inputNum = $(this).val();
    parentID = $(e.target).closest('[data-parent]').attr('id');

    let if_email = false,
      if_phone = false;

    $(`#${parentID} #phone_msg_error`).empty();

    if (inputNum.match('^[6-9][0-9]{9}$')) {
      if_phone = true;
      not_both = false;
    }
    else if (/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/.test(inputNum)) {
      if_email = true;
      not_both = false;
    }
    else {
      not_both = true;
    }

    if (if_email) {
      $('.hide_for_ph').show();
      $('.display-table').css('display', 'table');
      $(`#${parentID} .otp_get`).hide();
      $('.info-snip').css('padding', '0px 5px')
      $('.registered-users.to_hide_login').css('padding', '0px')
    }
    else if (if_phone) {
      if ($('.hide_for_ph').css('display') != 'none') {
        $('.hide_for_ph').hide();
        $('.info-snip').css('padding', '17px 5px')
        $('.registered-users.to_hide_login').css('padding', '14px 0px')
      }
      $(`#${parentID} .otp_get`).show();

    }
    else {
      not_both = true;
    }
  });

  // ERROR HANDLING
  $('.otp_get').on('click', function (e) {
    e.preventDefault();

    let emailRegex = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
      phoneError = false,
      emailError = false,
      emptyFields = false;

    parentID = $(e.target).closest('[data-parent]').attr('id');
    inputNum = $(`#${parentID} #customer_phone_number`).val();


    $(`#${parentID} #phone_msg_error`).empty();

    if (parentID == "CustomerRegisterForm") {
      $(`#CustomerRegisterForm [required]`).each((index, elem) => {
        if (!$(elem).val()) {

          emptyFields = true;
          e.stopImmediatePropagation();
          e.preventDefault();
          return;
        }
      })
    }
    else if (parentID == "CustomerLoginForm" && not_both == true) {
      $(`#${parentID} #phone_msg_error`).html('Please enter a correct email address or phone number.');
      e.stopImmediatePropagation();
      e.preventDefault();
      return;
    }
    if (emptyFields) {
      $(`#${parentID} #phone_msg_error`).html('Please fill in the required fields.');
      e.stopImmediatePropagation();
      e.preventDefault();
      return;
    }
    if (!inputNum.match('^[6-9][0-9]{9}$')) {
      phoneError = true;
    }
    if (parentID == "CustomerRegisterForm" && emailRegex.test($(`#${parentID} #Email`).val()) == false) {
      emailError = true;
    }
    if (emailError && phoneError) {
      $(`#${parentID} #phone_msg_error`).html('Please enter a correct email address and phone number.');
      e.stopImmediatePropagation();
      e.preventDefault();
      return;
    }
    else if (emailError) {
      $(`#${parentID} #phone_msg_error`).html('Please enter a correct email address.');
      e.stopImmediatePropagation();
      e.preventDefault();
      return;
    }
    else if (phoneError) {
      $(`#${parentID} #phone_msg_error`).html('Please enter a correct phone number.');
      e.stopImmediatePropagation();
      e.preventDefault();
      return;
    }
  })

  $(document).on('click', '.otp_get', function (e) {
    e.preventDefault();
    
    let timerOn = true;

    parentID = $(e.target).closest('[data-parent]').attr('id');
    inputNum = $(`#${parentID} #customer_phone_number`).val();
    inputOtp = $(`#${parentID} #verify_code`).val();
    inputFname = $(`#${parentID} #FirstName`).val();
    inputLname = $(`#${parentID} #LastName`).val();
    inputEmail = $(`#${parentID} #Email`).val();
    inputPass = $(`#${parentID} #CreatePassword`).val();
    data = {}

    if (parentID == "CustomerRegisterForm") {
      data = {
        "first_name": inputFname,
        "last_name": inputLname,
        "email": inputEmail,
        "password": inputPass,
        "phone": inputNum
      }
    }
    else {
      data = {
        "phone": inputNum
      }
    }


    $.ajax({
      type: "POST",
      url: sendOtpUrl,
      data: data,
      success: function (data) {
        $(`#${parentID} #otp_msg`).html('OTP Successfully Sent to ' + inputNum);
        hideAndShow(parentID, false, e.target);
      },
      error: function (response) {
        $('#errormsg').html(`${response.responseJSON.error}`)
        $('#go_back').html('Go back');
      },
      dataType: 'json',
    });

    //After otp send timer function
    timerCalled[parentID]++

    function timer(remaining) {
      if (timerCalled[parentID] > 1 && remaining >= 0) {
        timerCalled[parentID] = 1;
        clearTimeout(myTimeout[parentID]);
        timer(30);
        return;
      }

      var m = Math.floor(remaining / 60);
      var s = remaining % 60;

      m = m < 10 ? '0' + m : m;
      s = s < 10 ? '0' + s : s;
      $(`#${parentID} #timer`).html(m + ':' + s);
      remaining -= 1;


      if (remaining >= 0 && timerOn) {
        myTimeout[parentID] = setTimeout(function () {
          timer(remaining);
        }, 1000);
        return;
      }

      if (!timerOn) {
        // Do validate stuff here
        return;
      }

      // Do timeout stuff here
      $(`#${parentID} .resend-otp`).hide();
      $(`#${parentID} .resend-btn`).show();
    }

    timer(30);

  });

  $(document).on('click', '.verify_otp', function (e) {
    e.preventDefault();
    
    parentID = $(e.target).closest('[data-parent]').attr('id');
    inputNum = $(`#${parentID} #customer_phone_number`).val();
    inputOtp = $(`#${parentID} #verify_code`).val();
    inputFname = $(`#${parentID} #FirstName`).val();
    inputLname = $(`#${parentID} #LastName`).val();
    inputEmail = $(`#${parentID} #Email`).val();
    inputPass = $(`#${parentID} #CreatePassword`).val();
    data = {}

    if (parentID == "CustomerRegisterForm") {
      data = {
        "first_name": inputFname,
        "last_name": inputLname,
        "email": inputEmail,
        "password": inputPass,
        "phone": inputNum,
        "otp": inputOtp
      }
    }
    else {
      data = {
        "phone": inputNum,
        "otp": inputOtp
      }
    }


    $.ajax({
      type: "POST",
      url: verifyOtpUrl,
      data: data,
      dataType: 'json',
      success: function (result) {
        

        $(`#${parentID} #otp_msg`).html('Successfully Verified');
        $(`#${parentID} #verify_otp`).attr("disabled", true);
        $(`#${parentID} #verify_otp`).css("opacity", "0.45");
        otpVerified = true;
        window.location.href = result.login_url;;
      },
      error: function (result) {
        $('#errormsg').html(`${result.responseJSON.error}`)
        $(`#${parentID} .boxx`).hide()
        $('.to_hide_login').show();
        $('.phone_or_email').addClass('after_login_fail_otp');
        $(`#${parentID} [for="CustomerPhone"]`).html('Email<sup>*</sup>');
        $(`#${parentID} #customer_phone_number`).val('');
        $('.hide_for_ph').show();
        $('.display-table').css('display', 'table');
        $(`#${parentID} .otp_get`).hide();
        $(`#${parentID} #otp_msg_2`).html(`${result.responseJSON.error}`);
        console.log(result, "result error");
        return false;
      }
    });
  });


  $(document).on('click', '#resend__otp', function () {
    clearInterval(window.interval);
    TimerFunction();
  });

  $(".verify_otp").click(function (e) {
    parentID = $(e.target).closest('[data-parent]').attr('id');
    $(`#${parentID} #verify_code`).val($(`#${parentID} #digit-1`).val() + '' +
      $(`#${parentID} #digit-2`).val() + '' +
      $(`#${parentID} #digit-3`).val() + '' +
      $(`#${parentID} #digit-4`).val());
  });

  $('.otp-form').find('input').each(function () {
    $(this).attr('maxlength', 1);
    $(this).on('keyup', function (e) {
      var parent = $($(this).parent());

      var keyCode = e.keyCode || e.which;
      let inputNum = this.value;

      if (keyCode === 8 || keyCode === 37 || e.originalEvent.keyCode === 8) {
        var prev = parent.find('input#' + $(this).data('previous'));
        if (prev.length) {
          $(prev).select();
        }
      } else if (inputNum >= 0 && inputNum <= 9 && inputNum != "") {
        var next = parent.find('input#' + $(this).data('next'));
        if (next.length) {
          $(next).select();
        } else {
          if (parent.data('autosubmit')) {
            parent.submit();
          }
        }
      }
    });
  });

  $(".resend-btn").hide();

  $(".resend-btn").click(function (e) {
    var parentID = $(e.target).closest('[data-parent]').attr('id');
    $(`#${parentID} #otp_get`).trigger("click");
    $(`#${parentID} .resend-otp`).show();
    $(`#${parentID} .resend-btn`).hide();
  });

  $(".form-field").click(function () {
    if ($(".form-field-input").val().length === 0) {
      jQuery(this).find(".form-field-title").addClass("label-st");
    }
  });

</script>