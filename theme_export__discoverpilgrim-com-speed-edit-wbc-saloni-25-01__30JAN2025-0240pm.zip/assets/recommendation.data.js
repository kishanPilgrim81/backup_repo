var product_map={
  '7768274469093':{
    'frequency':'Daily',
    'function':'Cleanse',
    'sub_step':null
  },
  '7774893474021':{
    'frequency':'Daily',
    'function':'Cleanse',
    'sub_step':'Face serum'
  }
}
var three_step=['Cleanse','Treat','Moisturize']
var five_step=['Cleanse','Tone','Treat','Moisturize','Protect']